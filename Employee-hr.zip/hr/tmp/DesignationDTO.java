public class DesignationDTO
{
private int code;
private String title;
}
