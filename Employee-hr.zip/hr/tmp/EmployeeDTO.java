import java.util.*;
import java.math.*;
public class EmployeeDTO
{
private String employeeId;
private String name;
private int designationCode;
private Date dateOfBirth;
private char gender;
private boolean isIndian;
private BigDecimal basicSalary;
private String pANNumber;
private String aadharNumber;
}
