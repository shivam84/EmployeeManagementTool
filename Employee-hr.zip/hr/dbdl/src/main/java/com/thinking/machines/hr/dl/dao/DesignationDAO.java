package com.thinking.machines.hr.dl.dao;
import com.thinking.machines.hr.dl.dto.*;
import com.thinking.machines.hr.dl.interfaces.dao.*;
import com.thinking.machines.hr.dl.interfaces.dto.*;
import com.thinking.machines.hr.dl.exceptions.*;
import java.util.*;
import java.sql.*;
public class DesignationDAO implements DesignationDAOInterface
{
private static final String FILE_NAME="designation.data";
public void add(DesignationDTOInterface designationDTO) throws DAOException
{
if(designationDTO==null) throw new DAOException("Designation is null");
String title=designationDTO.getTitle();
if(title==null) throw new DAOException("Designation is null");
title=title.trim();
if(title.length()==0) throw new DAOException("Length of Designation is zero");
try
{
Connection connection=DAOConnection.getConnection();
PreparedStatement ps;
ps=connection.prepareStatement("select code from designation where title=?");
ps.setString(1,title);
ResultSet rs;
rs=ps.executeQuery();
if(rs.next())
{
ps.close();
rs.close();
connection.close();
throw new DAOException("Designation "+title+"exists.");
}
ps.close();
rs.close();
ps=connection.prepareStatement("insert into designation(title) values(?)",Statement.RETURN_GENERATED_KEYS);
ps.setString(1,title);
ps.executeUpdate();
rs=ps.getGeneratedKeys();
rs.next();
int code=rs.getInt(1);
rs.close();
ps.close();
connection.close();
designationDTO.setCode(code);
}
catch(SQLException sqle)
{
throw new DAOException(sqle.getMessage());
}
}
public void update(DesignationDTOInterface designationDTO) throws DAOException
{
if(designationDTO==null) throw new DAOException("Designation is null");
int code=designationDTO.getCode();
if(code<=0) throw new DAOException("Invalid code"+code);
String title=designationDTO.getTitle();
if(title==null) throw new DAOException("Designation is null");
title=title.trim();
if(title.length()==0) throw new DAOException("Length of Designation is zero");
try
{
Connection connection=DAOConnection.getConnection();
PreparedStatement ps;
ps=connection.prepareStatement("select code from designation where code=?");
ps.setInt(1,code);
ResultSet rs;
rs=ps.executeQuery();
if(rs.next()==false)
{
ps.close();
rs.close();
connection.close();
throw new DAOException("Code "+code+" does not exists.");
}
ps=connection.prepareStatement("select code from designation where title=? and code!=?");
ps.setString(1,title);
ps.setInt(2,code);
rs=ps.executeQuery();
if(rs.next())
{
ps.close();
rs.close();
connection.close();
throw new DAOException("Designation "+title+" already exists.");
}
ps.close();
rs.close();
ps=connection.prepareStatement("update designation set title=? where code=?");
ps.setString(1,title);
ps.setInt(2,code);
ps.executeUpdate();
ps.close();
connection.close();
}
catch(SQLException ioe)
{
throw new DAOException(ioe.getMessage());
}
}
public void delete(int code) throws DAOException
{
if(code<=0) throw new DAOException("Invalid code"+code);
try
{
Connection connection=DAOConnection.getConnection();
PreparedStatement ps;
ps=connection.prepareStatement("select * from designation where code=?");
ps.setInt(1,code);
ResultSet rs;
rs=ps.executeQuery();
if(rs.next()==false)
{
rs.close();
ps.close();
connection.close();
throw new DAOException("Code "+code+" does not exists.");
}
String designation=rs.getString("title").trim();
rs.close();
ps.close();
ps=connection.prepareStatement("select gender from employee where designation_code=?");
ps.setInt(1,code);
rs=ps.executeQuery();
if(rs.next())
{
rs.close();
ps.close();
connection.close();
throw new DAOException("Designation "+designation +"cannot be alloted as it has been alloted to employees");
}
rs.close();
ps.close();
ps=connection.prepareStatement("delete from designation where code=?");
ps.setInt(1,code);
ps.executeUpdate();
ps.close();
connection.close();
}catch(SQLException ioe)
{
throw new DAOException(ioe.getMessage());
}
}
public Set<DesignationDTOInterface> getAll() throws DAOException
{
Set<DesignationDTOInterface> designations;
designations=new TreeSet<>();
try
{
Connection connection=DAOConnection.getConnection();
Statement s;
s=connection.createStatement();
ResultSet rs;
rs=s.executeQuery("select * from designation");
DesignationDTOInterface designationDTO;
while(rs.next())
{
designationDTO=new DesignationDTO();
designationDTO.setCode(rs.getInt("code"));
designationDTO.setTitle(rs.getString("title").trim());
designations.add(designationDTO);
}
s.close();
rs.close();
connection.close();
return designations;
}
catch(SQLException ioe)
{
throw new DAOException(ioe.getMessage());
}
}
public DesignationDTOInterface getByCode(int code) throws DAOException
{
if (code<=0) throw new DAOException("Invalid code" +code);
try
{
Connection connection=DAOConnection.getConnection();
PreparedStatement ps;
ps=connection.prepareStatement("select title from designation where code=?");
ps.setInt(1,code);
ResultSet rs=ps.executeQuery();
if(rs.next()==true)
{
DesignationDTOInterface designationDTO=new DesignationDTO();
designationDTO.setCode(rs.getInt("code"));
designationDTO.setTitle(rs.getString("title").trim());
ps.close();
rs.close();
connection.close();
return designationDTO;
}
ps.close();
rs.close();
connection.close();
throw new DAOException("Invalid code" +code);
}catch(SQLException ioe)
{
throw new DAOException(ioe.getMessage());
}
}
public DesignationDTOInterface getByTitle(String title) throws DAOException
{
if (title==null) throw new DAOException("Invalid title" +title);
try
{
Connection connection=DAOConnection.getConnection();
PreparedStatement ps;
ps=connection.prepareStatement("select code from designation where title=?");
ps.setString(1,title);
ResultSet rs=ps.executeQuery();
if(rs.next())
{
DesignationDTOInterface designationDTO=new DesignationDTO();
designationDTO.setCode(rs.getInt("code"));
designationDTO.setTitle(rs.getString("title").trim());
ps.close();
rs.close();
connection.close();
return designationDTO;
}
ps.close();
rs.close();
connection.close();
throw new DAOException("Invalid title" +title);
}catch(SQLException ioe)
{
throw new DAOException(ioe.getMessage());
}

}
public boolean codeExists(int code) throws DAOException
{
if (code<=0) return false;
try
{
Connection connection=DAOConnection.getConnection();
PreparedStatement ps;
ps=connection.prepareStatement("select code from designation where code=?");
ps.setInt(1,code);
ResultSet rs=ps.executeQuery();
if(rs.next())
{
return true;
}
return false;
}catch(SQLException ioe)
{
throw new DAOException(ioe.getMessage());
}
}
public boolean titleExists(String title) throws DAOException
{
if (title==null || title.trim().length()==0) return false;
title=title.trim();
try
{
Connection connection=DAOConnection.getConnection();
PreparedStatement ps;
ps=connection.prepareStatement("select code from designation where title=?");
ps.setString(1,title);
ResultSet rs=ps.executeQuery();
if(rs.next())
{
return true;
}
return false;
}catch(SQLException ioe)
{
throw new DAOException(ioe.getMessage());
}
}
public int getCount() throws DAOException
{
try
{
Connection connection=DAOConnection.getConnection();
Statement ps;
ps=connection.createStatement();
ResultSet rs;
rs=ps.executeQuery("select count(*) as count from designation");
rs.next();
int count=rs.getInt("count");
rs.close();
ps.close();
connection.close();
return count;
}catch(SQLException ioe)
{
throw new DAOException(ioe.getMessage());
}
}
}
