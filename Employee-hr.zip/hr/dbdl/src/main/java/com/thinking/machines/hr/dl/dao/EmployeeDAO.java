package com.thinking.machines.hr.dl.dao;
import com.thinking.machines.hr.dl.exceptions.*;
import com.thinking.machines.enums.*;
import com.thinking.machines.hr.dl.interfaces.dto.*;
import com.thinking.machines.hr.dl.interfaces.dao.*;
import com.thinking.machines.hr.dl.dto.*;
import java.util.*;
import java.text.*;
import java.math.*;
import java.io.*;
import java.sql.*;
import com.thinking.machines.hr.dl.dao.*;
public class EmployeeDAO implements EmployeeDAOInterface
{
private final String FILE_NAME="employee.data";
public void add(EmployeeDTOInterface employeeDTO) throws DAOException
{
String employeeId;
if(employeeDTO==null) throw new DAOException("employee is null");
String name=employeeDTO.getName();
if(name==null) throw new DAOException("Name is null");
name=name.trim();
if(name.length()==0) throw new DAOException("Length of name is zero");
int designationCode=employeeDTO.getDesignationCode();
if(designationCode<=0) throw new DAOException("designation code is zero");

Connection connection=null;
PreparedStatement ps;
ResultSet rs;
try
{
connection=DAOConnection.getConnection();
ps=connection.prepareStatement("select code from designation where code=?");
ps.setInt(1,designationCode);
rs=ps.executeQuery();
if(rs.next()==false)
{
rs.close();
ps.close();
connection.close();
throw new DAOException("Incorrect designatrionCode"+designationCode);
}
}catch(SQLException s)
{
throw new DAOException(s.getMessage());
}
java.util.Date dateOfBirth=employeeDTO.getDateOfBirth();
if(dateOfBirth==null) throw new DAOException("Date of Birth is null");
char gender=employeeDTO.getGender();
if(gender==' ') throw new DAOException("Incorrect Gender");
boolean isIndian=employeeDTO.getIsIndian();
BigDecimal basicSalary=employeeDTO.getBasicSalary();
if(basicSalary==null) throw new DAOException("salary cannot be null");
if(basicSalary.signum()==-1) throw new DAOException("salary cannot be negative");
String panNumber=employeeDTO.getPANNumber();
if(panNumber==null) throw new DAOException("PAN number cannot be null");
panNumber=panNumber.trim();
if(panNumber.length()==0) throw new DAOException("Length of PAN Number cannot be zero ");
boolean panNumberExists=false;
try{
ps=connection.prepareStatement("select gender from employee where pan_number=?");
ps.setString(1,panNumber);
rs=ps.executeQuery();
if(rs.next())
{
panNumberExists=true;
}
}catch(SQLException e)
{
System.out.println(e.getMessage());
}
String aadharCardNumber=employeeDTO.getAadharCardNumber();
if(aadharCardNumber==null) throw new DAOException("Aadhar number cannot be null");
aadharCardNumber=aadharCardNumber.trim();
if(aadharCardNumber.length()==0) throw new DAOException("Length of Aadhar card Number cannot be zero ");
boolean aadharCardNumberExists=false;
try{
ps=connection.prepareStatement("select gender from employee where aadhar_card_number=?");
ps.setString(1,aadharCardNumber);
rs=ps.executeQuery();
if(rs.next())
{
aadharCardNumberExists=true;
}
}catch(SQLException e)
{
throw new DAOException(e.getMessage());
}
if(panNumberExists==true && aadharCardNumberExists==true)
{
try{
rs.close();
ps.close();
connection.close();
}catch(SQLException s){throw new DAOException(s.getMessage());}
throw new DAOException("PAN number "+panNumber+" Aadhar Number"+aadharCardNumber+" already exist");
}
if(panNumberExists==true)
{
try{
rs.close();
ps.close();
connection.close();
}catch(SQLException s){throw new DAOException(s.getMessage());}
throw new DAOException("PAN number "+panNumber+" exist");
}
if(aadharCardNumberExists==true)
{
try{
rs.close();
ps.close();
connection.close();
}catch(SQLException s){throw new DAOException(s.getMessage());}
throw new DAOException(" Aadhar Number"+aadharCardNumber+" already exist");
}
try
{
ps=connection.prepareStatement("insert into employee(name,designation_code,date_of_birth,gender,is_indian,basic_salary,pan_number,aadhar_card_number) values(?,?,?,?,?,?,?,?)",Statement.RETURN_GENERATED_KEYS);
ps.setString(1,name);
ps.setInt(2,designationCode);
java.sql.Date sqlDateOfBirth=new java.sql.Date(dateOfBirth.getYear(),dateOfBirth.getMonth(),dateOfBirth.getDate());
ps.setDate(3,sqlDateOfBirth);
ps.setString(4,String.valueOf(gender));
ps.setBoolean(5,isIndian);
ps.setBigDecimal(6,basicSalary);
ps.setString(7,panNumber);
ps.setString(8,aadharCardNumber);
ps.executeUpdate();
rs=ps.getGeneratedKeys();
rs.next();
int generatedEmployeeId=rs.getInt(1);
employeeId=("A"+(1000000+generatedEmployeeId));
rs.close();
ps.close();
connection.close();
employeeDTO.setEmployeeId(employeeId);
}catch(SQLException ioe)
{
throw new DAOException(ioe.getMessage());
}
}
public void update(EmployeeDTOInterface employeeDTO) throws DAOException
{
if(employeeDTO==null) throw new DAOException("employee is null");
String employeeId;
employeeId=employeeDTO.getEmployeeId();
if(employeeId==null) throw new DAOException("Employee ID is null");
employeeId=employeeId.trim();
if(employeeId.length()==0) throw new DAOException("Length of employee id zero");
int actualEmployeeId;
try
{
actualEmployeeId=Integer.parseInt(employeeId.substring(1))-1000000;
}catch(Exception e)
{
throw new DAOException("Invalid employee Id");
}
Connection connection=null;
PreparedStatement ps;
ResultSet rs;
int newEmployeeId=Integer.parseInt(employeeId.substring(7,8));
try
{
connection=DAOConnection.getConnection();
ps=connection.prepareStatement("select gender from employee where employee_id=?");
ps.setInt(1,newEmployeeId);
rs=ps.executeQuery();
if(rs.next()==false)
{
ps.close();
rs.close();
connection.close();
throw new DAOException("EmployeeId"+ employeeId+" does not exist");
}
}catch(SQLException s)
{
throw new DAOException(s.getMessage());
}
String name=employeeDTO.getName();
if(name==null) throw new DAOException("Name is null");
name=name.trim();
if(name.length()==0) throw new DAOException("Length of name is zero");
int designationCode=employeeDTO.getDesignationCode();
if(designationCode<=0) throw new DAOException("designation code is zero");
try
{
connection=DAOConnection.getConnection();
ps=connection.prepareStatement("select code from designation where code=?");
ps.setInt(1,designationCode);
rs=ps.executeQuery();
if(rs.next()==false)
{
rs.close();
ps.close();
connection.close();
throw new DAOException("Incorrect designatrionCode"+designationCode);
}
}catch(SQLException s)
{
throw new DAOException(s.getMessage());
}
java.util.Date dateOfBirth=employeeDTO.getDateOfBirth();
if(dateOfBirth==null) throw new DAOException("Date of Birth is null");
char gender=employeeDTO.getGender();
if(gender==' ') throw new DAOException("Incorrect Gender");
boolean isIndian=employeeDTO.getIsIndian();
BigDecimal basicSalary=employeeDTO.getBasicSalary();
if(basicSalary==null) throw new DAOException("salary cannot be null");
if(basicSalary.signum()==-1) throw new DAOException("salary cannot be negative");
String panNumber=employeeDTO.getPANNumber();
if(panNumber==null) throw new DAOException("PAN number cannot be null");
panNumber=panNumber.trim();
if(panNumber.length()==0)
{
try
{
connection.close();
}catch(SQLException s)
{
throw new DAOException(s.getMessage());
}
throw new DAOException("Length of PAN Number cannot be zero ");
}
String aadharCardNumber=employeeDTO.getAadharCardNumber();
if(aadharCardNumber==null) throw new DAOException("Aadhar number cannot be null");
aadharCardNumber=aadharCardNumber.trim();
if(aadharCardNumber.length()==0)
{
try
{
connection.close();
}catch(SQLException s)
{
throw new DAOException(s.getMessage());
}
throw new DAOException("Length of Aadhar card Number cannot be zero ");
}
try
{
boolean panNumberExists;
ps=connection.prepareStatement("select gender from employee where pan_number=? and employee_id<>?");
ps.setString(1,panNumber);
ps.setInt(2,actualEmployeeId);
rs=ps.executeQuery();
panNumberExists=rs.next();
rs.close();
ps.close();
boolean aadharCardNumberExists;
ps=connection.prepareStatement("select gender from employee where aadhar_card_number=? and employee_id<>?");
ps.setString(1,aadharCardNumber);
ps.setInt(2,actualEmployeeId);
rs=ps.executeQuery();
aadharCardNumberExists=rs.next();
rs.close();
ps.close();
if(panNumberExists==true && aadharCardNumberExists==true)
{
try
{
connection.close();
}catch(SQLException s)
{
throw new DAOException(s.getMessage());
}
throw new DAOException("PAN number "+panNumber+" Aadhar Number"+aadharCardNumber+" already exist");
}
if(panNumberExists==true)
{
try
{
connection.close();
}catch(SQLException s)
{
throw new DAOException(s.getMessage());
}
throw new DAOException("PAN number "+panNumber+" exist");
}
if(aadharCardNumberExists==true)
{
try
{
connection.close();
}catch(SQLException s)
{
throw new DAOException(s.getMessage());
}
throw new DAOException(" Aadhar Number"+aadharCardNumber+" already exist");
}

ps=connection.prepareStatement("update employee set name=?,designation_code=?,date_of_birth=?,gender=?,is_indian=?,basic_salary=?,pan_number=?,aadhar_card_number=? where employee_id=?");
ps.setString(1,name);
ps.setInt(2,designationCode);
java.sql.Date sqlDateOfBirth=new java.sql.Date(dateOfBirth.getYear(),dateOfBirth.getMonth(),dateOfBirth.getDate());
ps.setDate(3,sqlDateOfBirth);
ps.setString(4,String.valueOf(gender));
ps.setBoolean(5,isIndian);
ps.setBigDecimal(6,basicSalary);
ps.setString(7,panNumber);
ps.setString(8,aadharCardNumber);
ps.setInt(9,actualEmployeeId);
ps.executeUpdate();
ps.close();
connection.close();  
}catch(SQLException ioe)
{
System.out.println(ioe.getMessage());
}
}
public void delete(String employeeId) throws DAOException
{
if(employeeId==null) throw new DAOException("Employee ID is null");
employeeId=employeeId.trim();
if(employeeId.length()==0) throw new DAOException("Length of employee id zero");
int actualEmployeeId;
try
{
actualEmployeeId=Integer.parseInt(employeeId.substring(1))-1000000;
}catch(Exception e)
{
throw new DAOException("Invalid employee Id");
}
Connection connection=DAOConnection.getConnection();
PreparedStatement ps;
ResultSet rs;
try
{
ps=connection.prepareStatement("select gender from employee where employee_id=?");
ps.setInt(1,actualEmployeeId);
rs=ps.executeQuery();
if(rs.next()==false)
{
rs.close();
ps.close();
connection.close();  
throw new DAOException("Invalid Employee Id "+employeeId);
}
rs.close();
ps.close();
ps=connection.prepareStatement("delete from employee where employee_id=?");
ps.setInt(1,actualEmployeeId);
ps.executeUpdate();
ps.close();
connection.close();  
}catch(SQLException ioe)
{
System.out.println(ioe.getMessage());
}
}
public Set<EmployeeDTOInterface> getAll() throws DAOException
{
Set<EmployeeDTOInterface> employee=new TreeSet<>(); 
try
{
Connection connection=DAOConnection.getConnection();
PreparedStatement ps;
ps=connection.prepareStatement("select * from employee");
ResultSet rs;
rs=ps.executeQuery();
EmployeeDTOInterface employeeDTO;
java.util.Date utilDateOfBirth;
java.sql.Date sqlDateOfBirth;
String gender;
while(rs.next())
{
employeeDTO=new EmployeeDTO();
String generatedEmployeeId="A"+(rs.getInt("employee_id")+1000000);
employeeDTO.setEmployeeId(generatedEmployeeId);
employeeDTO.setName(rs.getString("name").trim());
employeeDTO.setDesignationCode(rs.getInt("designation_code"));
sqlDateOfBirth=rs.getDate("date_of_birth");
utilDateOfBirth =new java.util.Date(sqlDateOfBirth.getYear(),sqlDateOfBirth.getMonth(),sqlDateOfBirth.getDate());
employeeDTO.setDateOfBirth(utilDateOfBirth);
gender=rs.getString("gender");
employeeDTO.setGender((gender.equals("M"))?GENDER.MALE:GENDER.FEMALE);
employeeDTO.setIsIndian(rs.getBoolean("is_indian"));
employeeDTO.setBasicSalary(rs.getBigDecimal("basic_salary"));
employeeDTO.setPANNumber(rs.getString("pan_number").trim());
employeeDTO.setAadharCardNumber(rs.getString("aadhar_card_number").trim());
employee.add(employeeDTO);
}
rs.close();
ps.close();
connection.close(); 
return employee;
}
catch(SQLException ioe)
{
throw new DAOException(ioe.getMessage());
}
}
public Set<EmployeeDTOInterface> getByDesignationCode(int designationCode) throws DAOException
{
Set<EmployeeDTOInterface> employee=new TreeSet<>(); 
try
{
Connection connection=DAOConnection.getConnection();
PreparedStatement ps;
ps=connection.prepareStatement("select code from designation where code=?");
ps.setInt(1,designationCode);
ResultSet rs;
rs=ps.executeQuery();
if(rs.next()==false)
{
rs.close();
ps.close();
connection.close(); 
throw new DAOException("Invalid Designation code "+designationCode);
}
rs.close();
ps.close();
ps=connection.prepareStatement("select * from employee where designation_code=?");
ps.setInt(1,designationCode);
rs=ps.executeQuery();
EmployeeDTOInterface employeeDTO;
java.util.Date utilDateOfBirth;
java.sql.Date sqlDateOfBirth;
String gender;
while(rs.next())
{
employeeDTO=new EmployeeDTO();
String generatedEmployeeId="A"+(rs.getInt("employee_id")+1000000);
employeeDTO.setEmployeeId(generatedEmployeeId);
employeeDTO.setName(rs.getString("name").trim());
employeeDTO.setDesignationCode(rs.getInt("designation_code"));
sqlDateOfBirth=rs.getDate("date_of_birth");
utilDateOfBirth =new java.util.Date(sqlDateOfBirth.getYear(),sqlDateOfBirth.getMonth(),sqlDateOfBirth.getDate());
employeeDTO.setDateOfBirth(utilDateOfBirth);
gender=rs.getString("gender");
employeeDTO.setGender((gender.equals("M"))?GENDER.MALE:GENDER.FEMALE);
employeeDTO.setIsIndian(rs.getBoolean("is_indian"));
employeeDTO.setBasicSalary(rs.getBigDecimal("basic_salary"));
employeeDTO.setPANNumber(rs.getString("pan_number").trim());
employeeDTO.setAadharCardNumber(rs.getString("aadhar_card_number").trim());
employee.add(employeeDTO);
}
rs.close();
ps.close();
connection.close(); 
return employee;
}
catch(SQLException ioe)
{
throw new DAOException(ioe.getMessage());
}
}
public EmployeeDTOInterface getByEmployeeId(String employeeId) throws DAOException
{
if(employeeId==null) throw new DAOException("InvaLID employee id"+employeeId);
employeeId=employeeId.trim();
if(employeeId.length()==0) throw new DAOException("Invalid employeeID"+employeeId);
int actualEmployeeId=0;
try
{
actualEmployeeId=Integer.parseInt(employeeId.substring(1))-1000000;
}catch(Exception e)
{
throw new DAOException("Invalid employeeID"+employeeId);
}
EmployeeDTOInterface employeeDTO=null;
try
{
Connection connection=DAOConnection.getConnection();
PreparedStatement ps;
ps=connection.prepareStatement("select * from employee where employee_id=?");
ps.setInt(1,actualEmployeeId);
ResultSet rs;
rs=ps.executeQuery();
if(rs.next()==false)
{
rs.close();
ps.close();
connection.close(); 
throw new DAOException("Invalid employeeId code "+employeeId);
}
rs.close();
ps.close();
java.util.Date utilDateOfBirth;
java.sql.Date sqlDateOfBirth;
String gender;
while(rs.next())
{
employeeDTO=new EmployeeDTO();
String generatedEmployeeId="A"+(rs.getInt("employee_id")+1000000);
employeeDTO.setEmployeeId(generatedEmployeeId);
employeeDTO.setName(rs.getString("name").trim());
employeeDTO.setDesignationCode(rs.getInt("designation_code"));
sqlDateOfBirth=rs.getDate("date_of_birth");
utilDateOfBirth =new java.util.Date(sqlDateOfBirth.getYear(),sqlDateOfBirth.getMonth(),sqlDateOfBirth.getDate());
employeeDTO.setDateOfBirth(utilDateOfBirth);
gender=rs.getString("gender");
employeeDTO.setGender((gender.equals("M"))?GENDER.MALE:GENDER.FEMALE);
employeeDTO.setIsIndian(rs.getBoolean("is_indian"));
employeeDTO.setBasicSalary(rs.getBigDecimal("basic_salary"));
employeeDTO.setPANNumber(rs.getString("pan_number").trim());
employeeDTO.setAadharCardNumber(rs.getString("aadhar_card_number").trim());
}
rs.close();
ps.close();
connection.close(); 
}
catch(SQLException ioe)
{
throw new DAOException(ioe.getMessage());
}
return employeeDTO;
}
public EmployeeDTOInterface getByPANNumber(String panNumber) throws DAOException
{
if(panNumber==null) throw new DAOException("Invalid pan number"+panNumber);
panNumber=panNumber.trim();
if(panNumber.length()==0) throw new DAOException("Invalid paN number"+panNumber);
EmployeeDTOInterface employeeDTO=null;
try
{
Connection connection=DAOConnection.getConnection();
PreparedStatement ps;
ps=connection.prepareStatement("select gender from employee where pan_number=?");
ps.setString(1,panNumber);
ResultSet rs;
rs=ps.executeQuery();
if(rs.next()==false)
{
rs.close();
ps.close();
connection.close(); 
throw new DAOException("Invalid paN number"+panNumber);
}
rs.close();
ps.close();
ps=connection.prepareStatement("select * from employee where pan_number=?");
ps.setString(1,panNumber);
rs=ps.executeQuery();
java.util.Date utilDateOfBirth;
java.sql.Date sqlDateOfBirth;
String gender;
while(rs.next())
{
employeeDTO=new EmployeeDTO();
String generatedEmployeeId="A"+(rs.getInt("employee_id")+1000000);
employeeDTO.setEmployeeId(generatedEmployeeId);
employeeDTO.setName(rs.getString("name").trim());
employeeDTO.setDesignationCode(rs.getInt("designation_code"));
sqlDateOfBirth=rs.getDate("date_of_birth");
utilDateOfBirth =new java.util.Date(sqlDateOfBirth.getYear(),sqlDateOfBirth.getMonth(),sqlDateOfBirth.getDate());
employeeDTO.setDateOfBirth(utilDateOfBirth);
gender=rs.getString("gender");
employeeDTO.setGender((gender.equals("M"))?GENDER.MALE:GENDER.FEMALE);
employeeDTO.setIsIndian(rs.getBoolean("is_indian"));
employeeDTO.setBasicSalary(rs.getBigDecimal("basic_salary"));
employeeDTO.setPANNumber(rs.getString("pan_number").trim());
employeeDTO.setAadharCardNumber(rs.getString("aadhar_card_number").trim());
}
rs.close();
ps.close();
connection.close(); 
}
catch(SQLException ioe)
{
throw new DAOException(ioe.getMessage());
}
return employeeDTO;
}
public EmployeeDTOInterface getByAadharNumber(String aadharNumber) throws DAOException
{
if(aadharNumber==null) throw new DAOException("InvaLID Aadhar number"+aadharNumber);
aadharNumber=aadharNumber.trim();
if(aadharNumber.length()==0) throw new DAOException("InvaLID Aadhar number"+aadharNumber);
EmployeeDTOInterface employeeDTO=null;
try
{
Connection connection=DAOConnection.getConnection();
PreparedStatement ps;
ps=connection.prepareStatement("select gender from employee where aadhar_card_number=?");
ps.setString(1,aadharNumber);
ResultSet rs;
rs=ps.executeQuery();
if(rs.next()==false)
{
rs.close();
ps.close();
connection.close(); 
throw new DAOException("Invalid paN number"+aadharNumber);
}
rs.close();
ps.close();
ps=connection.prepareStatement("select * from employee where aadhar_card_number=?");
ps.setString(1,aadharNumber);
rs=ps.executeQuery();
java.util.Date utilDateOfBirth;
java.sql.Date sqlDateOfBirth;
String gender;
while(rs.next())
{
employeeDTO=new EmployeeDTO();
String generatedEmployeeId="A"+(rs.getInt("employee_id")+1000000);
employeeDTO.setEmployeeId(generatedEmployeeId);
employeeDTO.setName(rs.getString("name").trim());
employeeDTO.setDesignationCode(rs.getInt("designation_code"));
sqlDateOfBirth=rs.getDate("date_of_birth");
utilDateOfBirth =new java.util.Date(sqlDateOfBirth.getYear(),sqlDateOfBirth.getMonth(),sqlDateOfBirth.getDate());
employeeDTO.setDateOfBirth(utilDateOfBirth);
gender=rs.getString("gender");
employeeDTO.setGender((gender.equals("M"))?GENDER.MALE:GENDER.FEMALE);
employeeDTO.setIsIndian(rs.getBoolean("is_indian"));
employeeDTO.setBasicSalary(rs.getBigDecimal("basic_salary"));
employeeDTO.setPANNumber(rs.getString("pan_number").trim());
employeeDTO.setAadharCardNumber(rs.getString("aadhar_card_number").trim());
}
rs.close();
ps.close();
connection.close(); 
}
catch(SQLException ioe)
{
throw new DAOException(ioe.getMessage());
}
return employeeDTO;
}
public boolean employeeIdExists(String employeeId) throws DAOException
{
boolean employeeExist=false;
if(employeeId==null) throw new DAOException("InvaLID employee id"+employeeId);
employeeId=employeeId.trim();
if(employeeId.length()==0) throw new DAOException("Invalid employeeID"+employeeId);
int actualEmployeeId=0;
try
{
actualEmployeeId=Integer.parseInt(employeeId.substring(1))-1000000;
}catch(Exception e)
{
throw new DAOException("Invalid employeeID"+employeeId);
}
try
{
Connection connection=DAOConnection.getConnection();
PreparedStatement ps;
ps=connection.prepareStatement("select gender from employee where employee_id=?");
ps.setInt(1,actualEmployeeId);
ResultSet rs;
rs=ps.executeQuery();
if(rs.next()==false)
{
rs.close();
ps.close();
connection.close(); 
throw new DAOException("Invalid employeeId code "+employeeId);
}
employeeExist=true;
rs.close();
ps.close();
connection.close(); 
}
catch(SQLException ioe)
{
throw new DAOException(ioe.getMessage());
}
return employeeExist;
}
public boolean panNumberExists(String panNumber) throws DAOException
{
if(panNumber==null) throw new DAOException("Invalid pan number"+panNumber);
panNumber=panNumber.trim();
if(panNumber.length()==0) throw new DAOException("Invalid paN number"+panNumber);
boolean panNumberExist=false;
try
{
Connection connection=DAOConnection.getConnection();
PreparedStatement ps;
ps=connection.prepareStatement("select gender from employee where pan_number=?");
ps.setString(1,panNumber);
ResultSet rs;
rs=ps.executeQuery();
if(rs.next()==false)
{
rs.close();
ps.close();
connection.close(); 
throw new DAOException("Invalid paN number"+panNumber);
}
panNumberExist=true;
rs.close();
ps.close();
connection.close(); 
}
catch(SQLException ioe)
{
throw new DAOException(ioe.getMessage());
}
return panNumberExist;
}
public boolean aadharNumberExists(String aadharNumber) throws DAOException
{
if(aadharNumber==null) throw new DAOException("InvaLID Aadhar number"+aadharNumber);
aadharNumber=aadharNumber.trim();
if(aadharNumber.length()==0) throw new DAOException("InvaLID Aadhar number"+aadharNumber);
boolean aadharNumberExist=false;
try
{
Connection connection=DAOConnection.getConnection();
PreparedStatement ps;
ps=connection.prepareStatement("select gender from employee where aadhar_card_number=?");
ps.setString(1,aadharNumber);
ResultSet rs;
rs=ps.executeQuery();
if(rs.next()==false)
{
rs.close();
ps.close();
connection.close(); 
throw new DAOException("Invalid paN number"+aadharNumber);
}
aadharNumberExist=true;
rs.close();
ps.close();
connection.close(); 
}
catch(SQLException ioe)
{
throw new DAOException(ioe.getMessage());
}
return aadharNumberExist;
}
public boolean isDesignationAlloted(int designationCode) throws DAOException
{
boolean designationAlloted=false;
try
{
Connection connection=DAOConnection.getConnection();
PreparedStatement ps;
ps=connection.prepareStatement("select code from designation where code=?");
ps.setInt(1,designationCode);
ResultSet rs;
rs=ps.executeQuery();
if(rs.next()==false)
{
rs.close();
ps.close();
connection.close(); 
throw new DAOException("Invalid Designation code "+designationCode);
}
rs.close();
ps.close();
ps=connection.prepareStatement("select gender from employee where designation_code=?");
ps.setInt(1,designationCode);
rs=ps.executeQuery();
designationAlloted=true;
rs.close();
ps.close();
connection.close(); 
}
catch(SQLException ioe)
{
throw new DAOException(ioe.getMessage());
}
return designationAlloted;
}
public int getCount() throws DAOException
{
int recordCount=0;
try
{
Connection connection=DAOConnection.getConnection();
Statement s;
s=connection.createStatement();
ResultSet rs;
rs=s.executeQuery("select count(*) as count from employee");
rs.next();
recordCount=rs.getInt("count");
s.close();
rs.close();
connection.close();
}
catch(SQLException ioe)
{
throw new DAOException(ioe.getMessage());
}
return recordCount;
}
public int getCountByDesignation(int designationCode) throws DAOException
{
int count=0;
try
{
Connection connection=DAOConnection.getConnection();
PreparedStatement ps;
ps=connection.prepareStatement("select code from designation where code=?");
ps.setInt(1,designationCode);
ResultSet rs;
rs=ps.executeQuery();
if(rs.next()==false)
{
rs.close();
ps.close();
connection.close(); 
throw new DAOException("Invalid Designation code "+designationCode);
}
rs.close();
ps.close();
ps=connection.prepareStatement("select count(*) as count from employee where designation_code=?");
ps.setInt(1,designationCode);
rs=ps.executeQuery();
rs.next();
count=rs.getInt("count");
rs.close();
ps.close();
connection.close();
}
catch(SQLException ioe)
{
throw new DAOException(ioe.getMessage());
}
return count;
}
}