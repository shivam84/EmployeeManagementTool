import com.thinking.machines.hr.dl.interfaces.dao.*;
import com.thinking.machines.hr.dl.interfaces.dto.*;
import com.thinking.machines.hr.dl.exceptions.*;
import java.util.*;
import java.io.*;
import com.thinking.machines.hr.dl.dao.*;
import com.thinking.machines.hr.dl.dto.*;

public class EmployeePanNumberExists
{
public static void main(String gg[])
{
try
{
boolean b=false;
String panNumber=gg[0];
EmployeeDTOInterface ddtoi=new EmployeeDTO();
EmployeeDAOInterface ddaoi=new EmployeeDAO();
b=ddaoi.panNumberExists(panNumber);
System.out.println("Pan Number: "+b);
}catch(DAOException daoe)
{
System.out.println(daoe.getMessage());
}
}
} 