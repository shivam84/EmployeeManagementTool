class aaa
{
public static void main(String gg[])
{
String a="A1000013";
a=a.substring(6,8);
System.out.println(a);
}
}