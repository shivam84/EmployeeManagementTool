import com.thinking.machines.hr.dl.interfaces.dao.*;
import com.thinking.machines.hr.dl.interfaces.dto.*;
import com.thinking.machines.hr.dl.exceptions.*;
import java.util.*;
import java.io.*;
import com.thinking.machines.hr.dl.dao.*;
import com.thinking.machines.hr.dl.dto.*;

public class DesignationUpdateTestCase
{
public static void main(String gg[])
{
try
{
int code=Integer.parseInt(gg[0]);
String title=gg[1];
DesignationDTOInterface ddtoi=new DesignationDTO();
ddtoi.setCode(code);
ddtoi.setTitle(title);
DesignationDAOInterface ddaoi=new DesignationDAO();
ddaoi.update(ddtoi); 
System.out.println("Designation updated "+ddtoi.getTitle()+" "+ddtoi.getCode());
}catch(DAOException daoe)
{
System.out.println(daoe.getMessage());
}

}
} 