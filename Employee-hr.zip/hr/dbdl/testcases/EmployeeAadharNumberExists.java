import com.thinking.machines.hr.dl.interfaces.dao.*;
import com.thinking.machines.hr.dl.interfaces.dto.*;
import com.thinking.machines.hr.dl.exceptions.*;
import java.util.*;
import java.io.*;
import com.thinking.machines.hr.dl.dao.*;
import com.thinking.machines.hr.dl.dto.*;

public class EmployeeAadharNumberExists
{
public static void main(String gg[])
{
try
{
boolean b=false;
String aadharNumber=gg[0];
EmployeeDTOInterface ddtoi=new EmployeeDTO();
EmployeeDAOInterface ddaoi=new EmployeeDAO();
b=ddaoi.aadharNumberExists(aadharNumber);
System.out.println("AadharNumber: "+b);
}catch(DAOException daoe)
{
System.out.println(daoe.getMessage());
}
}
} 