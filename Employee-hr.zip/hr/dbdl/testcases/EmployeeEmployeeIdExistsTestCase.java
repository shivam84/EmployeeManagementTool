import com.thinking.machines.hr.dl.interfaces.dao.*;
import com.thinking.machines.hr.dl.interfaces.dto.*;
import com.thinking.machines.hr.dl.exceptions.*;
import java.util.*;
import java.io.*;
import com.thinking.machines.hr.dl.dao.*;
import com.thinking.machines.hr.dl.dto.*;

public class EmployeeEmployeeIdExistsTestCase
{
public static void main(String gg[])
{
try
{
boolean b=false;
String employeeId=gg[0];
EmployeeDTOInterface ddtoi=new EmployeeDTO();
EmployeeDAOInterface ddaoi=new EmployeeDAO();
b=ddaoi.employeeIdExists(employeeId);
System.out.println("EmployeeId: "+b);
}catch(DAOException daoe)
{
System.out.println(daoe.getMessage());
}
}
} 