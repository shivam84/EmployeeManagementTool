import com.thinking.machines.hr.dl.interfaces.dao.*;
import com.thinking.machines.hr.dl.interfaces.dto.*;
import com.thinking.machines.hr.dl.exceptions.*;
import java.util.*;
import java.io.*;
import com.thinking.machines.hr.dl.dao.*;
import com.thinking.machines.hr.dl.dto.*;
import java.awt.*;
import javax.swing.*;
import javax.swing.table.*;
class alag extends AbstractTableModel
{
Set<DesignationDTOInterface> designations;
DesignationDAOInterface ddaoi;
alag()
{
populateDS();
}
private void populateDS()
{
try
{
ddaoi=new DesignationDAO();
designations=ddaoi.getAll();
ArrayList<DesignationDTOInterface> l=new ArrayList<>();
l.add(designations);
}catch(DAOException daoe)
{
System.out.println(daoe.getMessage());
}
}
public int getRowCount()
{
return designations.size();
}
public int getColumnCount()
{
return 3;
}
public String getColumnName(int columnIndex)
{
if(columnIndex==0) return "S.No";
if(columnIndex==1) return "Code";
if(columnIndex==2) return "Title";
}
public Object getValueAt(int rowIndex,int columnIndex)
{
if(columnIndex==0) return rowIndex+1;
DesignationDTOInterface ddto=designations.get(rowIndex+1);
if(columnIndex==1) return dto.getCode();
if(columnIndex==2) return ddto.getTitle();
}
public boolean isCellEditable(int row,int column)
{
return false;
}
public Class getColumnClass(int columnIndex)
{
Class c=null;
try
{
if(columnIndex==1||columnIndex==0) return c=Class.forName("java.lang.Integer");
else return c=Class.forName("java.lang.String");
}
catch(Exception e)
{
System.out.println(e);
}
}
}
class tableCreation extends JFrame
{
private JTable table;
private Container container;
private alag al;
tableCreation()
{
al=new alag();
table=new JTable(al);
container=getContentPane();
setLocation(600,500);
setSize(600,600);
setVisible(true);
}
}

public class DesignationGetAllTestCase1
{
public static void main(String gg[])
{
tableCreation tc=new tableCreation();
}
} 