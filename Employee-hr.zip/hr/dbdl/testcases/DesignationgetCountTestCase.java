import com.thinking.machines.hr.dl.interfaces.dao.*;
import com.thinking.machines.hr.dl.exceptions.*;
import com.thinking.machines.hr.dl.dao.*;
public class DesignationgetCountTestCase
{
public static void main(String gg[])
{
try
{
DesignationDAOInterface ddaoi=new DesignationDAO();
System.out.println("Designation count "+ddaoi.getCount());
}catch(DAOException daoe)
{
System.out.println(daoe.getMessage());
}
}
} 