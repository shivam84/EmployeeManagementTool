import com.thinking.machines.hr.dl.interfaces.dao.*;
import com.thinking.machines.hr.dl.interfaces.dto.*;
import com.thinking.machines.hr.dl.exceptions.*;
import java.util.*;
import java.io.*;
import com.thinking.machines.hr.dl.dao.*;
import com.thinking.machines.hr.dl.dto.*;

public class DesignationGetByTitleTestCase
{
public static void main(String gg[])
{
try
{
String title=gg[0];
DesignationDTOInterface ddtoi=new DesignationDTO();
DesignationDAOInterface ddaoi=new DesignationDAO();
ddtoi=ddaoi.getByTitle(title);
System.out.println("Code: "+ddtoi.getCode()+" "+ddtoi.getTitle()+"Exist");
}catch(DAOException daoe)
{
System.out.println(daoe.getMessage());
}

}
} 