import com.thinking.machines.hr.dl.interfaces.dao.*;
import com.thinking.machines.hr.dl.exceptions.*;
import com.thinking.machines.hr.dl.dao.*;
public class EmployeeGetCountTestCase
{
public static void main(String gg[])
{
try
{
EmployeeDAOInterface ddaoi=new EmployeeDAO();
System.out.println("Employee count "+ddaoi.getCount());
}catch(DAOException daoe)
{
System.out.println(daoe.getMessage());
}
}
} 