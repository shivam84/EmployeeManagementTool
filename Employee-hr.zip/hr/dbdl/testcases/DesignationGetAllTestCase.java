import com.thinking.machines.hr.dl.interfaces.dao.*;
import com.thinking.machines.hr.dl.interfaces.dto.*;
import com.thinking.machines.hr.dl.exceptions.*;
import java.util.*;
import java.io.*;
import com.thinking.machines.hr.dl.dao.*;
import com.thinking.machines.hr.dl.dto.*;

public class DesignationGetAllTestCase
{
public static void main(String gg[])
{
try
{
DesignationDAOInterface ddaoi=new DesignationDAO();
Set<DesignationDTOInterface> designations=ddaoi.getAll();
designations.forEach((d)->{System.out.println("Designation "+d.getTitle()+" "+d.getCode());
});
}catch(DAOException daoe)
{
System.out.println(daoe.getMessage());
}

}
} 