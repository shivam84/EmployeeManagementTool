import com.thinking.machines.hr.dl.interfaces.dao.*;
import com.thinking.machines.hr.dl.interfaces.dto.*;
import com.thinking.machines.hr.dl.exceptions.*;
import java.util.*;
import java.io.*;
import com.thinking.machines.hr.dl.dao.*;
import com.thinking.machines.hr.dl.dto.*;

public class DesignationTitleExistsTestCase
{
public static void main(String gg[])
{
try
{
boolean b;
String title=gg[0];
DesignationDTOInterface ddtoi=new DesignationDTO();
DesignationDAOInterface ddaoi=new DesignationDAO();
b=ddaoi.titleExists(title);
System.out.println("Title: "+ddtoi.getTitle()+b+"exist");
}catch(DAOException daoe)
{
System.out.println(daoe.getMessage());
}

}
} 