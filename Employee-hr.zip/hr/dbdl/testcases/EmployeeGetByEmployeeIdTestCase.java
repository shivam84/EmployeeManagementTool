import com.thinking.machines.hr.dl.interfaces.dao.*;
import com.thinking.machines.hr.dl.interfaces.dto.*;
import com.thinking.machines.hr.dl.exceptions.*;
import java.util.*;
import com.thinking.machines.enums.*;
import java.io.*;
import java.math.*;
import java.text.*;
import com.thinking.machines.hr.dl.dao.*;
import com.thinking.machines.hr.dl.dto.*;
public class EmployeeGetByEmployeeIdTestCase
{
public static void main(String gg[])
{
String employeeId=gg[0];
try
{
EmployeeDAOInterface employeeDAO=new EmployeeDAO();
EmployeeDTOInterface employeeDTO;
employeeDTO=employeeDAO.getByEmployeeId(employeeId);
SimpleDateFormat sdf=new SimpleDateFormat("dd/MM/yyyy");
System.out.println("Employee ID: "+employeeDTO.getEmployeeId());
System.out.println("Name"+employeeDTO.getName());
System.out.println("Designation Code"+employeeDTO.getDesignationCode());
System.out.println("Date of Birth"+sdf.format(employeeDTO.getDateOfBirth()));
System.out.println("Gender"+employeeDTO.getGender());
System.out.println("Is Indian"+employeeDTO.getIsIndian());
System.out.println("Basic Salary"+employeeDTO.getBasicSalary());
System.out.println("Pan Number"+employeeDTO.getPANNumber());
System.out.println("AAdhar Number"+employeeDTO.getAadharCardNumber());
}catch(DAOException daoe)
{
System.out.println(daoe.getMessage());
}
}
} 