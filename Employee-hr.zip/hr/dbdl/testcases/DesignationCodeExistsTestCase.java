import com.thinking.machines.hr.dl.interfaces.dao.*;
import com.thinking.machines.hr.dl.interfaces.dto.*;
import com.thinking.machines.hr.dl.exceptions.*;
import java.util.*;
import java.io.*;
import com.thinking.machines.hr.dl.dao.*;
import com.thinking.machines.hr.dl.dto.*;

public class DesignationCodeExistsTestCase
{
public static void main(String gg[])
{
try
{
boolean b=false;
int code=Integer.parseInt(gg[0]);
DesignationDTOInterface ddtoi=new DesignationDTO();
DesignationDAOInterface ddaoi=new DesignationDAO();
b=ddaoi.codeExists(code);
System.out.println("Code: "+b);
}catch(DAOException daoe)
{
System.out.println(daoe.getMessage());
}
}
} 