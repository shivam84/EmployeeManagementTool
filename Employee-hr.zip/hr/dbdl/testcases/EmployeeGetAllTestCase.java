import com.thinking.machines.hr.dl.interfaces.dao.*;
import com.thinking.machines.hr.dl.interfaces.dto.*;
import com.thinking.machines.hr.dl.exceptions.*;
import java.util.*;
import java.io.*;
import com.thinking.machines.hr.dl.dao.*;
import com.thinking.machines.hr.dl.dto.*;

public class EmployeeGetAllTestCase
{
public static void main(String gg[])
{
try
{
EmployeeDAOInterface ddaoi=new EmployeeDAO();
Set<EmployeeDTOInterface> employee=ddaoi.getAll();
employee.forEach((d)->{System.out.println("Employee "+d.getEmployeeId()+" "+d.getName()+" "+d.getDesignationCode()+" "+d.getDateOfBirth()+" "+d.getGender()+" "+d.getIsIndian()+" "+d.getBasicSalary()+" "+d.getPANNumber()+" "+d.getAadharCardNumber());
System.out.println("****************************************");
});
}catch(DAOException daoe)
{
System.out.println(daoe.getMessage());
}

}
} 