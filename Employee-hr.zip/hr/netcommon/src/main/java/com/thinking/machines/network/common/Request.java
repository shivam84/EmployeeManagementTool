package com.thinking.machines.network.common;
public class Request implements java.io.Serializable
{
private String manager;
private String action;
private Object[] arguements;
public void setManager(String manager)
{
this.manager=manager;
}
public String getManager()
{
return this.manager;
}
public void setAction(String action)
{
this.action=action;
}
public String getAction()
{
return this.action;
}
public void setArguements(Object ...arguements)
{
this.arguements=arguements;
}
public Object[] getArguements()
{
return this.arguements;
}
}