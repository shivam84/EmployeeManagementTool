package com.thinking.machines.network.common.exceptions;
public class NetworkException extends Exception
{
public NetworkException()
{

}
public NetworkException(String message)
{
super(message);
}

}