package com.thinking.machines.network.client;
import com.thinking.machines.network.common.*;
import com.thinking.machines.network.common.exceptions.*;
import java.io.*;
import java.net.*; 
public class NetworkClient
{
public Response send(Request request) throws NetworkException
{
try
{
ByteArrayOutputStream baos=new ByteArrayOutputStream();
ObjectOutputStream oos=new ObjectOutputStream(baos);
oos.writeObject(request);
oos.flush();
byte objectByte[];
objectByte=baos.toByteArray();
int requestLength=objectByte.length;       
                                             // requestLength = 161
byte header[]=new byte[1024];
int x,i;
i=1023;
x=requestLength;
while(x>0)
{
header[i]=(byte)(x%10);
x=x/10;
i--;
}
Socket socket=new Socket("localhost",5500);
OutputStream os=socket.getOutputStream();
os.write(header,0,1024);
os.flush();								

InputStream is=socket.getInputStream();
byte ack[]=new byte[1];
int bytesReadCount;
while(true)
{
bytesReadCount=is.read(ack);  
                                 	           //bytes read=1
if(bytesReadCount==-1) continue;
break;
}
int bytesToSend=requestLength;
int chunkSize=1024;
int j=0;
while(j<bytesToSend)
{
if((bytesToSend-j)<chunkSize) chunkSize=bytesToSend-j;
os.write(objectByte,j,chunkSize);
os.flush();
j=j+chunkSize;
}
int bytesToReceive=1024;
byte temp[]=new byte[1024];
int k;
i=0;
j=0;
while(j<bytesToReceive)
{
bytesReadCount=is.read(temp);
if(bytesReadCount==-1) continue;           // temp=   00000......19
                                           //bytes read =1024
for(k=0;k<bytesReadCount;k++)
{
header[i]=temp[k];                          //header=00000......19
i++;
}
j=j+bytesReadCount;
}
int responseLength=0;
i=1;
j=1023;
while(j>=0)
{
responseLength=responseLength+(header[j]*i);                   
i=i*10;
j--;
}
//System.out.println("Header received" +responseLength);            //19
ack[0]=1;
os.write(ack,0,1);
os.flush();
byte response[]=new byte[responseLength];
bytesToReceive=responseLength;
i=0;
j=0;
while(j<bytesToReceive)
{
bytesReadCount=is.read(temp);
if(bytesReadCount==-1) continue;
for(k=0;k<bytesReadCount;k++)
{
response[i]=temp[k];
i++;
}
for(int p=0;p<response.length;p++)  System.out.println(response[p]);
j=j+bytesReadCount;
}
System.out.println("Response Received");
ack[0]=1;
os.write(ack);
os.flush();
socket.close();
ByteArrayInputStream bais=new ByteArrayInputStream(response);
ObjectInputStream ois=new ObjectInputStream(bais);
Response responseObject=(Response)ois.readObject();
return responseObject;
}
catch(Exception ne)
{
throw new NetworkException(ne.getMessage());
}
}
} 
