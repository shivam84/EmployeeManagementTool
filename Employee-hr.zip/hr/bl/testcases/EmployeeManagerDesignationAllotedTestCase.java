import com.thinking.machines.hr.bl.interfaces.managers.*;
import com.thinking.machines.hr.bl.interfaces.pojo.*;
import com.thinking.machines.hr.bl.managers.*;
import com.thinking.machines.hr.bl.pojo.*;
import com.thinking.machines.hr.bl.exceptions.*;
import com.thinking.machines.enums.*;
import java.util.*;
import java.text.*;
import java.math.*;
class EmployeeManagerDesignationAllotedTestCase
{
public static void main(String gg[])
{
try
{
DesignationInterface designation=new Designation();
designation.setCode(0);
EmployeeInterface employee=new Employee();
employee.setDesignation(designation);
EmployeeManagerInterface employeeManager=EmployeeManager.getEmployeeManager();
boolean exist=employeeManager.designationAlloted(designation.getCode());
System.out.println("Designation " +designation.getCode()+exist);
}
catch(BLException blException)
{
if(blException.hasGenericException()) System.out.println(blException.getGenericException());
List<String> properties=blException.getProperties();
for(String property:properties)
{
System.out.println(blException.getException(property));
}
}
}
}