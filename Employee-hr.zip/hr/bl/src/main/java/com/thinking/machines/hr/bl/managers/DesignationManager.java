package com.thinking.machines.hr.bl.managers;
import com.thinking.machines.hr.bl.interfaces.pojo.*;
import com.thinking.machines.hr.bl.interfaces.managers.*;
import com.thinking.machines.hr.bl.pojo.*;
import com.thinking.machines.hr.bl.exceptions.*;
import com.thinking.machines.hr.dl.exceptions.*;
import com.thinking.machines.hr.dl.interfaces.dto.*;
import com.thinking.machines.hr.dl.interfaces.dao.*;
import com.thinking.machines.hr.dl.dao.*;
import com.thinking.machines.hr.dl.dto.*;
import java.util.*;
public class DesignationManager implements DesignationManagerInterface
{
private Map<Integer,DesignationInterface> codeWiseDesignationMap;
private Map<String,DesignationInterface> titleWiseDesignationMap;
private Set<DesignationInterface> designationSet;
private static DesignationManager designationManager=null;
private DesignationManager() throws BLException
{
populateDataStructures();
}
private void populateDataStructures() throws BLException
{
this.codeWiseDesignationMap=new HashMap<>();
this.titleWiseDesignationMap=new HashMap<>();
this.designationSet=new TreeSet<>();
try
{
Set<DesignationDTOInterface> dlDesignations;
dlDesignations=new DesignationDAO().getAll();
DesignationInterface designation;
for(DesignationDTOInterface dlDesignation:dlDesignations)
{
designation=new Designation();
designation.setCode(dlDesignation.getCode());
designation.setTitle(dlDesignation.getTitle());
this.codeWiseDesignationMap.put(designation.getCode(),designation);
this.titleWiseDesignationMap.put(designation.getTitle().toUpperCase(),designation);
this.designationSet.add(designation);
}
}catch(DAOException daoe)
{
BLException blException=new BLException();
blException.setGenericException(daoe.getMessage());
throw blException;
}
}
public static DesignationManagerInterface getDesignationManager() throws BLException
{
if(designationManager==null) designationManager=new DesignationManager();
return designationManager;
}
public void addDesignation(DesignationInterface designation) throws BLException
{
BLException blException=new BLException();
if(designation==null)
{
blException.setGenericException("Designation Required");
throw blException;
}
String title=designation.getTitle();
int code=designation.getCode();
if(code!=0)
{
blException.addException("code","code should be zero");
}
if(title==null)
{
blException.addException("title","title Required");
title="";
}
else
{
title=title.trim();
if(title.length()==0)
{
blException.addException("title","Title Required");
}
}
if(this.titleWiseDesignationMap.containsKey(title.toUpperCase()))
{
blException.addException("title","Designation" +title+ "Exist");
}
if(blException.hasExceptions())
{
throw blException;
}
try
{
DesignationDTOInterface designationDTO=new DesignationDTO();
designationDTO.setTitle(title);
DesignationDAOInterface designationDAO=new DesignationDAO();
designationDAO.add(designationDTO);
code=designationDTO.getCode();
designation.setCode(code);
Designation dsDesignation=new Designation();
dsDesignation.setTitle(title);
dsDesignation.setCode(code);
codeWiseDesignationMap.put(code,dsDesignation);
titleWiseDesignationMap.put(title.toUpperCase(),dsDesignation);
designationSet.add(dsDesignation);
}
catch(DAOException daoe)
{
blException.setGenericException(daoe.getMessage());
}
}
public void updateDesignation(DesignationInterface designation) throws BLException
{
BLException blException=new BLException();
if(designation==null)
{
blException.setGenericException("Designation Required");
throw blException;
}
String title=designation.getTitle();
int code=designation.getCode();
if(code<=0)
{
blException.addException("code","code should be +ve");
}
if(code>0)
{
if(this.codeWiseDesignationMap.containsKey(code)==false)
{
blException.addException("code","code does not exist");
throw blException;
}
}
if(title==null)
{
blException.addException("title","title Required");
title="";
}
else
{
title=title.trim();
if(title.length()==0)
{
blException.addException("title","Title Required");
}
}
DesignationInterface d=titleWiseDesignationMap.get(title.toUpperCase());
if(d!=null && d.getCode()!=code)
{
blException.addException("title","title already exist"+title);
}
if(blException.hasExceptions())
{
throw blException;
}
try
{
DesignationInterface dsDesignation=codeWiseDesignationMap.get(code);
DesignationDTOInterface dlDesignationDTO=new DesignationDTO();
dlDesignationDTO.setCode(code);
dlDesignationDTO.setTitle(title);
new DesignationDAO().update(dlDesignationDTO);
this.codeWiseDesignationMap.remove(code);
this.titleWiseDesignationMap.remove(dsDesignation.getTitle().toUpperCase());
this.designationSet.remove(dsDesignation);
dsDesignation.setTitle(title);
this.codeWiseDesignationMap.put(code,dsDesignation);
this.titleWiseDesignationMap.put(title.toUpperCase(),dsDesignation);
this.designationSet.add(dsDesignation);
}catch(DAOException daoe)
{
blException.setGenericException(daoe.getMessage());
}
}
public void removeDesignation(int code) throws BLException
{
BLException blException=new BLException();
if(code<=0)
{
blException.addException("code","code should be +ve");
throw blException;
}
if(code>0)
{
if(this.codeWiseDesignationMap.containsKey(code)==false)
{
blException.addException("code","code does not exist");
throw blException;
}
}
try
{
DesignationInterface dsDesignation=codeWiseDesignationMap.get(code);
new DesignationDAO().delete(code);
this.codeWiseDesignationMap.remove(code);
this.titleWiseDesignationMap.remove(dsDesignation.getTitle().toUpperCase());
this.designationSet.remove(dsDesignation);
}catch(DAOException daoe)
{
blException.setGenericException(daoe.getMessage());
throw blException;
}
}
public DesignationInterface getDesignationByCode(int code) throws BLException
{
DesignationInterface designation;
designation=codeWiseDesignationMap.get(code);
if(designation==null)
{
BLException blException=new BLException();
blException.addException("code","Invalid Code "+code);
throw blException;
}
DesignationInterface d=new Designation();
d.setCode(designation.getCode());
d.setTitle(designation.getTitle());
return d;
}

DesignationInterface getDSDesignationByCode(int code)
{
DesignationInterface designation;
designation=codeWiseDesignationMap.get(code);
return designation;
}


public DesignationInterface getDesignationByTitle(String title) throws BLException
{
DesignationInterface designation;
designation=titleWiseDesignationMap.get(title.toUpperCase());
if(designation==null)
{
BLException blException=new BLException();
blException.addException("title","Invalid Title "+title);
throw blException;
}
DesignationInterface d=new Designation();
d.setCode(designation.getCode());
d.setTitle(designation.getTitle());
return d;
}
public int getDesignationCount() 
{
return designationSet.size();
}

public Set<DesignationInterface> getDesignations() 
{
Set<DesignationInterface> designations;
designations=new TreeSet<>(); 
designationSet.forEach((designation)->{
DesignationInterface d=new Designation();
d.setCode(designation.getCode());
d.setTitle(designation.getTitle());
designations.add(d);
});
return designations;
}
public boolean codeExists(int code) 
{
return codeWiseDesignationMap.containsKey(code);
}
public boolean titleExists(String title) 
{
return titleWiseDesignationMap.containsKey(title.toUpperCase());
}
}