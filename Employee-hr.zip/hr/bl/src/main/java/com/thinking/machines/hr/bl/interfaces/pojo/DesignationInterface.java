package com.thinking.machines.hr.bl.interfaces.pojo;

public interface DesignationInterface extends java.io.Serializable,Comparable<DesignationInterface>
{
public void setCode(int code);
public int getCode();
public String getTitle();
public void setTitle(String title);
}