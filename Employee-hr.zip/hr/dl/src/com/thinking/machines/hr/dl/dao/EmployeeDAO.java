package com.thinking.machines.hr.dl.dao;
import com.thinking.machines.hr.dl.exceptions.*;
import com.thinking.machines.enums.*;
import com.thinking.machines.hr.dl.interfaces.dto.*;
import com.thinking.machines.hr.dl.interfaces.dao.*;
import com.thinking.machines.hr.dl.dto.*;
import java.util.*;
import java.text.*;
import java.math.*;
import java.io.*;
public class EmployeeDAO implements EmployeeDAOInterface
{
private final String FILE_NAME="employee.data";
public void add(EmployeeDTOInterface employeeDTO) throws DAOException
{
String employeeId;
if(employeeDTO==null) throw new DAOException("employee is null");
String name=employeeDTO.getName();
if(name==null) throw new DAOException("Name is null");
name=name.trim();
if(name.length()==0) throw new DAOException("Length of name is zero");
int designationCode=employeeDTO.getDesignationCode();
if(designationCode<=0) throw new DAOException("designation code is zero");
DesignationDAOInterface designationDAO=new DesignationDAO();
boolean isDesignationCodeValid=designationDAO.codeExists(designationCode);
if(isDesignationCodeValid==false) throw new DAOException("Incorrect designatrionCode"+designationCode);
Date dateOfBirth=employeeDTO.getDateOfBirth();
if(dateOfBirth==null) throw new DAOException("Date of Birth is null");
char gender=employeeDTO.getGender();
if(gender==' ') throw new DAOException("Incorrect Gender");
boolean isIndian=employeeDTO.getIsIndian();
BigDecimal basicSalary=employeeDTO.getBasicSalary();
if(basicSalary==null) throw new DAOException("salary cannot be null");
if(basicSalary.signum()==-1) throw new DAOException("salary cannot be negative");
String panNumber=employeeDTO.getPANNumber();
if(panNumber==null) throw new DAOException("PAN number cannot be null");
panNumber=panNumber.trim();
if(panNumber.length()==0) throw new DAOException("Length of PAN Number cannot be zero ");
String aadharCardNumber=employeeDTO.getAadharCardNumber();
if(aadharCardNumber==null) throw new DAOException("Aadhar number cannot be null");
aadharCardNumber=aadharCardNumber.trim();
if(aadharCardNumber.length()==0) throw new DAOException("Length of Aadhar card Number cannot be zero ");
try
{
File f=new File(FILE_NAME);
RandomAccessFile raf=new RandomAccessFile(f,"rw");
int lastGeneratedEmployeeId=10000000;
String lastGeneratedEmployeeIdString="";
int recordCount=0;
String recordCountString="";
String fPanNumber;
String fAadharCardNumber;
boolean fPanNumberExists=false;
boolean fAadharCardNumberExists=false;
if(raf.length()==0)
{
lastGeneratedEmployeeIdString=String.format("%-10d",lastGeneratedEmployeeId);
raf.writeBytes(lastGeneratedEmployeeIdString+"\n");
recordCountString=String.format("%-10d",recordCount);
raf.writeBytes(recordCountString+"\n");
}
else
{
lastGeneratedEmployeeId=Integer.parseInt(raf.readLine().trim());
recordCount=Integer.parseInt(raf.readLine().trim());
}
while(raf.getFilePointer()<raf.length())
{
for(int x=1;x<=7;x++) raf.readLine();
fPanNumber=raf.readLine();
fAadharCardNumber=raf.readLine();
if(fPanNumber.equals(panNumber)) fPanNumberExists=true;
if(fAadharCardNumber.equals(aadharCardNumber)) fAadharCardNumberExists=true;
}
if(fPanNumberExists==true && fAadharCardNumberExists==true)
{
raf.close();
throw new DAOException("PAN number "+panNumber+" Aadhar Number"+aadharCardNumber+" already exist");
}
if(fPanNumberExists==true)
{
raf.close();
throw new DAOException("PAN number "+panNumber+" exist");
}
if(fAadharCardNumberExists==true)
{
raf.close();
throw new DAOException(" Aadhar Number"+aadharCardNumber+" already exist");
}
lastGeneratedEmployeeId++;
employeeId="A"+String.format("%-10d",lastGeneratedEmployeeId);
recordCount++;
raf.writeBytes(employeeId+"\n");
raf.writeBytes(name+"\n");
raf.writeBytes(String.valueOf(designationCode)+"\n");
SimpleDateFormat sdf=new SimpleDateFormat("dd/MM/yyyy");
raf.writeBytes(sdf.format(dateOfBirth)+"\n");
raf.writeBytes(gender+"\n");
raf.writeBytes(isIndian+"\n");
raf.writeBytes(basicSalary.toPlainString()+"\n");
raf.writeBytes(panNumber+"\n");
raf.writeBytes(aadharCardNumber+"\n");
raf.seek(0);
lastGeneratedEmployeeIdString=String.format("%-10d",lastGeneratedEmployeeId);
raf.writeBytes(lastGeneratedEmployeeIdString+"\n");
recordCountString=String.format("%-10d",recordCount);
raf.writeBytes(recordCountString+"\n");
raf.close();
employeeDTO.setEmployeeId(employeeId);
}catch(IOException ioe)
{
throw new DAOException(ioe.getMessage());
}
}
public void update(EmployeeDTOInterface employeeDTO) throws DAOException
{
if(employeeDTO==null) throw new DAOException("employee is null");
String employeeId;
employeeId=employeeDTO.getEmployeeId();
if(employeeId==null) throw new DAOException("Employee ID is null");
if(employeeId.length()==0) throw new DAOException("Length of employee id zero");
String name=employeeDTO.getName();
if(name==null) throw new DAOException("Name is null");
name=name.trim();
if(name.length()==0) throw new DAOException("Length of name is zero");
int designationCode=employeeDTO.getDesignationCode();
if(designationCode<=0) throw new DAOException("designation code is zero");
DesignationDAOInterface designationDAO=new DesignationDAO();
boolean isDesignationCodeValid=designationDAO.codeExists(designationCode);
if(isDesignationCodeValid==false) throw new DAOException("Incorrect designatrionCode"+designationCode);
Date dateOfBirth=employeeDTO.getDateOfBirth();
if(dateOfBirth==null) throw new DAOException("Date of Birth is null");
char gender=employeeDTO.getGender();
if(gender==' ') throw new DAOException("Incorrect Gender");
boolean isIndian=employeeDTO.getIsIndian();
BigDecimal basicSalary=employeeDTO.getBasicSalary();
if(basicSalary==null) throw new DAOException("salary cannot be null");
if(basicSalary.signum()==-1) throw new DAOException("salary cannot be negative");
String panNumber=employeeDTO.getPANNumber();
if(panNumber==null) throw new DAOException("PAN number cannot be null");
panNumber=panNumber.trim();
if(panNumber.length()==0) throw new DAOException("Length of PAN Number cannot be zero ");
String aadharCardNumber=employeeDTO.getAadharCardNumber();
if(aadharCardNumber==null) throw new DAOException("Aadhar number cannot be null");
aadharCardNumber=aadharCardNumber.trim();
if(aadharCardNumber.length()==0) throw new DAOException("Length of Aadhar card Number cannot be zero ");
try
{
File f=new File(FILE_NAME);
if(f.exists()==false) throw new DAOException("Invalid Employee id:: "+employeeId);
RandomAccessFile raf=new RandomAccessFile(f,"rw");
if(raf.length()==0) 
{
raf.close();
throw new DAOException("Invalid employeee id: "+employeeId);
}
raf.readLine();
raf.readLine();
SimpleDateFormat sdf=new SimpleDateFormat("dd/MM/yyyy");
String fEmployeeId;
String fName;
int fDesignationCode;
Date fDateOfBirth;
char fGender;
boolean fIsIndian;
BigDecimal fBasicSalary;
String fPanNumber;
String fAadharCardNumber;
boolean employeeIdFound=false;
boolean panNumberFound=false;
boolean aadharCardNumberFound=false;
String aadharCardNumberFoundAgainstEmployeeId=null;
String panNumberFoundAgainstEmployeeId=null;
long foundAt=0;
while(raf.getFilePointer()<raf.length())
{
if(employeeIdFound==false) foundAt=raf.getFilePointer();
fEmployeeId=raf.readLine().trim();
for(int x=1;x<=6;x++) raf.readLine();
fPanNumber=raf.readLine();
fAadharCardNumber=raf.readLine();
if(employeeIdFound==false && fEmployeeId.equalsIgnoreCase(employeeId))
{
employeeIdFound=true;
}
if(panNumberFound==false && fPanNumber.equalsIgnoreCase(panNumber))
{
panNumberFound=true;
panNumberFoundAgainstEmployeeId=fEmployeeId;
}
if(aadharCardNumberFound==false && fAadharCardNumber.equalsIgnoreCase(aadharCardNumber))
{
aadharCardNumberFound=true;
aadharCardNumberFoundAgainstEmployeeId=fEmployeeId;
}
if(employeeIdFound && panNumberFound && aadharCardNumberFound) break;
}
if(employeeIdFound==false)
{
raf.close(); 
System.out.println("Hello");
throw new DAOException("Invalid Employee id "+employeeId);
}
boolean panNumberExists=false;
boolean aadharCardNumberExists=false;
if(panNumberFound && panNumberFoundAgainstEmployeeId.equalsIgnoreCase(employeeId)==false)
{
panNumberExists=true;
}
if(aadharCardNumberFound && aadharCardNumberFoundAgainstEmployeeId.equalsIgnoreCase(employeeId)==false)
{
aadharCardNumberExists=true;
}
if(panNumberExists==true && aadharCardNumberExists==true)
{
raf.close();
throw new DAOException("PAN number "+panNumber+" Aadhar Number"+aadharCardNumber+" already exist");
}
if(panNumberExists==true)
{
raf.close();
throw new DAOException("PAN number "+panNumber+" exist");
}
if(aadharCardNumberExists==true)
{
raf.close();
throw new DAOException(" Aadhar Number"+aadharCardNumber+" already exist");
}
raf.seek(foundAt);
for(int x=1;x<=9;x++) raf.readLine();
File tfile=new File("tmp.tmp");
if(tfile.exists()==true) tfile.delete();
RandomAccessFile traf=new RandomAccessFile(tfile,"rw");
while(raf.getFilePointer()<raf.length())
{
traf.writeBytes(raf.readLine()+"\n");
}
raf.seek(foundAt);
raf.writeBytes(employeeId+"\n");
raf.writeBytes(name+"\n");
raf.writeBytes(String.valueOf(designationCode)+"\n");
raf.writeBytes(sdf.format(dateOfBirth)+"\n");
raf.writeBytes(gender+"\n");
raf.writeBytes(isIndian+"\n");
raf.writeBytes(basicSalary.toPlainString()+"\n");
raf.writeBytes(panNumber+"\n");
raf.writeBytes(aadharCardNumber+"\n");
traf.seek(0);
while(traf.getFilePointer()<traf.length())
{
raf.writeBytes(traf.readLine()+"\n");
}
raf.setLength(raf.getFilePointer());
traf.setLength(0);
raf.close();
traf.close();
}catch(IOException ioe)
{
System.out.println(ioe.getMessage());
}
}
public void delete(String employeeId) throws DAOException
{
if(employeeId==null) throw new DAOException("Employee id is null");
employeeId=employeeId.trim();
if(employeeId.length()==0) throw new DAOException("length of Employee id is zero");
try
{
File f=new File(FILE_NAME);
if(f.exists()==false) throw new DAOException("Invalid Employee id:: "+employeeId);
RandomAccessFile raf=new RandomAccessFile(f,"rw");
if(raf.length()==0) 
{
raf.close();
throw new DAOException("Invalid employeee id: "+employeeId);
}
raf.readLine();
int recordCount=Integer.parseInt(raf.readLine().trim());
String fEmployeeId;
long foundAt=0;
boolean employeeIdFound=false;
while(raf.getFilePointer()<raf.length())
{
foundAt=raf.getFilePointer();
fEmployeeId=raf.readLine().trim();
if(fEmployeeId.equalsIgnoreCase(employeeId))
{
employeeIdFound=true;
recordCount--;
File tf=new File("temp.temp");
if(tf.exists()==true) tf.delete();
RandomAccessFile traf=new RandomAccessFile(tf,"rw");
for(int x=1;x<=8;x++) raf.readLine();
while(raf.getFilePointer()<raf.length())
{
traf.writeBytes(raf.readLine()+"\n");
}
traf.seek(0);
raf.seek(foundAt);
while(traf.getFilePointer()<traf.length())
{
raf.writeBytes(traf.readLine()+"\n");
}
raf.setLength(raf.getFilePointer());
raf.seek(0);
raf.readLine();
String recordCountString=String.format("%-10d",recordCount);
raf.writeBytes(recordCountString+"\n");
raf.close();
traf.close();
return;
}
for(int x=1;x<=8;x++) raf.readLine();
}
raf.close();
throw new DAOException("Invalid employeee id: "+employeeId);
}catch(IOException ioe)
{
System.out.println(ioe.getMessage());
}
}
public Set<EmployeeDTOInterface> getAll() throws DAOException
{
Set<EmployeeDTOInterface> employee=new TreeSet<>(); 
try
{
File f=new File(FILE_NAME);
RandomAccessFile raf=new RandomAccessFile(f,"rw");
if(raf.length()==0)
{
raf.close();
return employee;
}
raf.readLine();
raf.readLine();
String fEmployeeId;
String fName;
int fDesignationCode;
Date fDateOfBirth;
char fGender;
boolean fIsIndian;
BigDecimal fBasicSalary;
String fPanNumber;
String fAadharCardNumber;
EmployeeDTOInterface employeeDTO;
while(raf.getFilePointer()<raf.length())
{
employeeDTO=new EmployeeDTO();
fEmployeeId=raf.readLine().trim();
fName=raf.readLine().trim();
fDesignationCode=Integer.parseInt(raf.readLine().trim());
SimpleDateFormat sdf=new SimpleDateFormat("dd/MM/yyyy");
try
{
fDateOfBirth=sdf.parse(raf.readLine().trim());
}catch(ParseException pe) {throw new DAOException(pe.getMessage());}
fGender=raf.readLine().charAt(0);
fIsIndian=Boolean.parseBoolean(raf.readLine().trim());
fBasicSalary=new BigDecimal(raf.readLine().trim());
fPanNumber=raf.readLine().trim();
fAadharCardNumber=raf.readLine().trim();
employeeDTO.setEmployeeId(fEmployeeId);
employeeDTO.setName(fName);
employeeDTO.setDesignationCode(fDesignationCode);
employeeDTO.setDateOfBirth(fDateOfBirth);
employeeDTO.setGender((fGender=='M')?GENDER.MALE:GENDER.FEMALE);
employeeDTO.setIsIndian(fIsIndian);
employeeDTO.setBasicSalary(fBasicSalary);
employeeDTO.setPANNumber(fPanNumber);
employeeDTO.setAadharCardNumber(fAadharCardNumber);
employee.add(employeeDTO);
}
raf.close();
return employee;
}
catch(IOException ioe)
{
throw new DAOException(ioe.getMessage());
}
}
public Set<EmployeeDTOInterface> getByDesignationCode(int designationCode) throws DAOException
{
if(new DesignationDAO().codeExists(designationCode)==false) throw new DAOException("Invalid designation code" +designationCode);
Set<EmployeeDTOInterface> employee=new TreeSet<>(); 
try
{
File f=new File(FILE_NAME);
RandomAccessFile raf=new RandomAccessFile(f,"rw");
if(raf.length()==0)
{
raf.close();
return employee;
}
raf.readLine();
raf.readLine();
boolean found=false;
String fEmployeeId;
String fName;
int fDesignationCode;
Date fDateOfBirth=null;
char fGender;
boolean fIsIndian;
BigDecimal fBasicSalary;
String fPanNumber;
String fAadharCardNumber;
EmployeeDTOInterface employeeDTO;
while(raf.getFilePointer()<raf.length())
{
employeeDTO=new EmployeeDTO();
fEmployeeId=raf.readLine();
fName=raf.readLine();
fDesignationCode=Integer.parseInt(raf.readLine());
if(fDesignationCode==designationCode)
{
SimpleDateFormat sdf=new SimpleDateFormat("dd/MM/yyyy");
try
{
fDateOfBirth=sdf.parse(raf.readLine().trim());
}catch(ParseException pe) 
{
//DO NOTHING
}
fGender=raf.readLine().charAt(0);
fIsIndian=Boolean.parseBoolean(raf.readLine());
fBasicSalary=new BigDecimal(raf.readLine());
fPanNumber=raf.readLine();
fAadharCardNumber=raf.readLine();
employeeDTO.setEmployeeId(fEmployeeId);
employeeDTO.setName(fName);
employeeDTO.setDesignationCode(fDesignationCode);
employeeDTO.setDateOfBirth(fDateOfBirth);
employeeDTO.setGender((fGender=='M')?GENDER.MALE:GENDER.FEMALE);
employeeDTO.setIsIndian(fIsIndian);
employeeDTO.setBasicSalary(fBasicSalary);
employeeDTO.setPANNumber(fPanNumber);
employeeDTO.setAadharCardNumber(fAadharCardNumber);
employee.add(employeeDTO);
found=true;
}
else
{
for(int x=1;x<=6;x++) raf.readLine();
}
}
raf.close();
if(found==false)
{
return employee;
}
return employee;
}
catch(IOException ioe)
{
throw new DAOException(ioe.getMessage());
}
}
public EmployeeDTOInterface getByEmployeeId(String employeeId) throws DAOException
{
if(employeeId==null) throw new DAOException("InvaLID employee id"+employeeId);
employeeId=employeeId.trim();
if(employeeId.length()==0) throw new DAOException("Invalid employeeID"+employeeId);
try
{
File f=new File(FILE_NAME);
if(f.exists()==false) throw new DAOException("invalid employee id"+employeeId);
RandomAccessFile raf=new RandomAccessFile(f,"rw");
if(raf.length()==0)
{
raf.close();
throw new DAOException(" invalid employee id");
}
raf.readLine();
raf.readLine();
EmployeeDTOInterface employeeDTO;
String fEmployeeId;
String fName;
int fDesignationCode;
SimpleDateFormat sdf=new SimpleDateFormat("dd/MM/yyyy");
Date fDateOfBirth;
char fGender;
boolean fIsIndian;
BigDecimal fBasicSalary;
String fPanNumber;
String fAadharCardNumber;

while(raf.getFilePointer()<raf.length())
{
fEmployeeId=raf.readLine();
if(fEmployeeId.equalsIgnoreCase(employeeId))
{
employeeDTO=new EmployeeDTO();
employeeDTO.setEmployeeId(fEmployeeId);
employeeDTO.setName(raf.readLine());
employeeDTO.setDesignationCode(Integer.parseInt(raf.readLine()));
try
{
employeeDTO.setDateOfBirth(sdf.parse(raf.readLine()));
}
catch(ParseException pe) 
{
//do nothing
}
employeeDTO.setGender((raf.readLine().charAt(0)=='M')?GENDER.MALE:GENDER.FEMALE);
employeeDTO.setIsIndian(Boolean.parseBoolean(raf.readLine()));
employeeDTO.setBasicSalary(new BigDecimal(raf.readLine()));
employeeDTO.setPANNumber(raf.readLine());
employeeDTO.setAadharCardNumber(raf.readLine());
raf.close();
return employeeDTO;
}
for(int x=1;x<=8;x++) raf.readLine();
}
raf.close();
throw new DAOException("Invalid Employee id"+ employeeId);
}
catch(IOException ioe)
{
throw new DAOException(ioe.getMessage());
}
}
public EmployeeDTOInterface getByPANNumber(String PanNumber) throws DAOException
{
if(PanNumber==null) throw new DAOException("InvaLID paN number"+PanNumber);
PanNumber=PanNumber.trim();
if(PanNumber.length()==0) throw new DAOException("InvaLID paN number"+PanNumber);
try
{
File f=new File(FILE_NAME);
if(f.exists()==false) throw new DAOException("InvaLID paN number"+PanNumber);
RandomAccessFile raf=new RandomAccessFile(f,"rw");
if(raf.length()==0)
{
raf.close();
throw new DAOException(" invalid PanNumber "+PanNumber);
}
raf.readLine();
raf.readLine();
EmployeeDTOInterface employeeDTO;
String fEmployeeId;
String fName;
int fDesignationCode;
Date fDateOfBirth=null;
char fGender;
boolean fIsIndian;
BigDecimal fBasicSalary;
String fPanNumber;
String fAadharCardNumber;
SimpleDateFormat sdf=new SimpleDateFormat("dd/MM/yyyy");
while(raf.getFilePointer()<raf.length())
{
fEmployeeId=raf.readLine(); 
fName=raf.readLine();
fDesignationCode=Integer.parseInt(raf.readLine());
try
{
fDateOfBirth=sdf.parse(raf.readLine());
}catch(ParseException pe)
{
//do nothing
}
fGender=raf.readLine().charAt(0);
fIsIndian=Boolean.parseBoolean(raf.readLine());
fBasicSalary=new BigDecimal(raf.readLine());
fPanNumber=raf.readLine();
fAadharCardNumber=raf.readLine();
if(fPanNumber.equalsIgnoreCase(PanNumber))
{
employeeDTO=new EmployeeDTO();
employeeDTO.setEmployeeId(fEmployeeId);
employeeDTO.setName(fName);
employeeDTO.setDesignationCode(fDesignationCode);
employeeDTO.setDateOfBirth(fDateOfBirth);
employeeDTO.setGender((fGender=='M')?GENDER.MALE:GENDER.FEMALE);
employeeDTO.setIsIndian(fIsIndian);
employeeDTO.setBasicSalary(fBasicSalary);
employeeDTO.setPANNumber(fPanNumber);
employeeDTO.setAadharCardNumber(fAadharCardNumber);
return employeeDTO;
}
}
raf.close(); 
throw new DAOException("Invalid pan Number"+PanNumber);
}
catch(IOException ioe)
{
throw new DAOException(ioe.getMessage());
}
}
public EmployeeDTOInterface getByAadharNumber(String aadharNumber) throws DAOException
{
if(aadharNumber==null) throw new DAOException("InvaLID Aadhar number"+aadharNumber);
aadharNumber=aadharNumber.trim();
if(aadharNumber.length()==0) throw new DAOException("InvaLID Aadhar number"+aadharNumber);
try
{
File f=new File(FILE_NAME);
if(f.exists()==false) throw new DAOException("InvaLID paN number"+aadharNumber);
RandomAccessFile raf=new RandomAccessFile(f,"rw");
if(raf.length()==0)
{
raf.close();
throw new DAOException(" invalid PanNumber "+aadharNumber);
}
raf.readLine();
raf.readLine();
EmployeeDTOInterface employeeDTO;
String fEmployeeId;
String fName;
int fDesignationCode;
Date fDateOfBirth=null;
char fGender;
boolean fIsIndian;
BigDecimal fBasicSalary;
String fPanNumber;
String fAadharCardNumber;
SimpleDateFormat sdf=new SimpleDateFormat("dd/MM/yyyy");
while(raf.getFilePointer()<raf.length())
{
fEmployeeId=raf.readLine(); 
fName=raf.readLine();
fDesignationCode=Integer.parseInt(raf.readLine());
try
{
fDateOfBirth=sdf.parse(raf.readLine());
}catch(ParseException pe)
{
//do nothing
}
fGender=raf.readLine().charAt(0);
fIsIndian=Boolean.parseBoolean(raf.readLine());
fBasicSalary=new BigDecimal(raf.readLine());
fPanNumber=raf.readLine();
fAadharCardNumber=raf.readLine();
if(fAadharCardNumber.equalsIgnoreCase(aadharNumber))
{
employeeDTO=new EmployeeDTO();
employeeDTO.setEmployeeId(fEmployeeId);
employeeDTO.setName(fName);
employeeDTO.setDesignationCode(fDesignationCode);
employeeDTO.setDateOfBirth(fDateOfBirth);
employeeDTO.setGender((fGender=='M')?GENDER.MALE:GENDER.FEMALE);
employeeDTO.setIsIndian(fIsIndian);
employeeDTO.setBasicSalary(fBasicSalary);
employeeDTO.setPANNumber(fPanNumber);
employeeDTO.setAadharCardNumber(fAadharCardNumber);
return employeeDTO;
}
}
raf.close(); 
throw new DAOException("Invalid AAdhar Number"+aadharNumber);
}
catch(IOException ioe)
{
throw new DAOException(ioe.getMessage());
}
}
public boolean employeeIdExists(String employeeID) throws DAOException
{
try
{
File f=new File(FILE_NAME);
RandomAccessFile raf=new RandomAccessFile(f,"rw");
if(raf.length()==0)
{
raf.close();
return false;
}
raf.readLine();
raf.readLine();
String fEmployeeId;
while(raf.getFilePointer()<raf.length())
{
fEmployeeId=raf.readLine().trim();
if(fEmployeeId.equalsIgnoreCase(employeeID))
{
return true;
}
for(int x=1;x<=8;x++) raf.readLine();
}
return false;
}
catch(IOException ioe)
{
throw new DAOException(ioe.getMessage());
}
}
public boolean panNumberExists(String panNumber) throws DAOException
{
try
{
File f=new File(FILE_NAME);
RandomAccessFile raf=new RandomAccessFile(f,"rw");
if(raf.length()==0)
{
raf.close();
return false;
}
raf.readLine();
raf.readLine();
String fPanNumber;
while(raf.getFilePointer()<raf.length())
{
for(int x=1;x<=7;x++) raf.readLine();
fPanNumber=raf.readLine().trim();
if(fPanNumber.equalsIgnoreCase(panNumber))
{
return true;
}
raf.readLine();
}
return false;
}
catch(IOException ioe)
{
throw new DAOException(ioe.getMessage());
}
}
public boolean aadharNumberExists(String aadharNumber) throws DAOException
{
try
{
File f=new File(FILE_NAME);
RandomAccessFile raf=new RandomAccessFile(f,"rw");
if(raf.length()==0)
{
raf.close();
return false;
}
raf.readLine();
raf.readLine();
String fAadharCardNumber;
while(raf.getFilePointer()<raf.length())
{
for(int x=1;x<=8;x++) raf.readLine();
fAadharCardNumber=raf.readLine().trim();
if(fAadharCardNumber.equalsIgnoreCase(aadharNumber))
{
return true;
}
}
return false;
}
catch(IOException ioe)
{
throw new DAOException(ioe.getMessage());
}
}
public boolean isDesignationAlloted(int designationCode) throws DAOException
{
try
{
File f=new File(FILE_NAME);
RandomAccessFile raf=new RandomAccessFile(f,"rw");
if(raf.length()==0)
{
raf.close();
return false;
}
raf.readLine();
raf.readLine();
int fDesignationCode;
while(raf.getFilePointer()<raf.length())
{
raf.readLine();
raf.readLine();
fDesignationCode=Integer.parseInt(raf.readLine().trim());
if(fDesignationCode==designationCode)
{
return true;
}
for(int x=1;x<=6;x++) raf.readLine();
}
return false;
}
catch(IOException ioe)
{
throw new DAOException(ioe.getMessage());
}

}
public int getCount() throws DAOException
{
try
{
File f=new File(FILE_NAME);
RandomAccessFile raf=new RandomAccessFile(f,"rw");
if(raf.length()==0)
{
raf.close();
return 0;
}
raf.readLine();
int recordCount=Integer.parseInt(raf.readLine().trim());
return recordCount;
}
catch(IOException ioe)
{
throw new DAOException(ioe.getMessage());
}
}
public int getCountByDesignation(int designationCode) throws DAOException
{
if(new DesignationDAO().codeExists(designationCode)==false) throw new DAOException("Invalid Designation code");
try
{
File f=new File(FILE_NAME);
if(f.exists()==false) return 0;
RandomAccessFile raf=new RandomAccessFile(f,"rw");
if(raf.length()==0)
{
raf.close();
return 0;
}
raf.readLine();
raf.readLine();
int fDesignationCode;
int count=0;
while(raf.getFilePointer()<raf.length())
{
raf.readLine();
raf.readLine();
fDesignationCode=Integer.parseInt(raf.readLine().trim());
if(fDesignationCode==designationCode)
{
count++;
}
for(int x=1;x<=6;x++) raf.readLine();
}
return count;
}
catch(IOException ioe)
{
throw new DAOException(ioe.getMessage());
}
}
}