package com.thinking.machines.hr.dl.dao;
import com.thinking.machines.hr.dl.dto.*;
import com.thinking.machines.hr.dl.interfaces.dao.*;
import com.thinking.machines.hr.dl.interfaces.dto.*;
import com.thinking.machines.hr.dl.exceptions.*;
import java.util.*;
import java.io.*;
public class DesignationDAO implements DesignationDAOInterface
{
private static final String FILE_NAME="designation.data";
public void add(DesignationDTOInterface designationDTO) throws DAOException
{
if(designationDTO==null) throw new DAOException("Designation is null");
String title=designationDTO.getTitle();
if(title==null) throw new DAOException("Designation is null");
title=title.trim();
if(title.length()==0) throw new DAOException("Length of Designation is zero");
try
{
File f=new File(FILE_NAME);
RandomAccessFile raf=new RandomAccessFile(f,"rw");
int lastGeneratedCode=0;
int recordCount=0;
String lastGeneratedCodeString="";
String recordCountString="";
if(raf.length()==0)
{
lastGeneratedCodeString="0";
while(lastGeneratedCodeString.length()<10) lastGeneratedCodeString+=" ";
recordCountString="0";
while(recordCountString.length()<10) recordCountString+=" ";
raf.writeBytes(lastGeneratedCodeString+"\n");
raf.writeBytes(recordCountString+"\n");
}
else
{
lastGeneratedCodeString=raf.readLine().trim();
recordCountString=raf.readLine().trim();
lastGeneratedCode=Integer.parseInt(lastGeneratedCodeString);
recordCount=Integer.parseInt(recordCountString);
}
int fCode;
String fTitle;
while(raf.getFilePointer()<raf.length())
{
fCode=Integer.parseInt(raf.readLine());
fTitle=raf.readLine();
if(title.equalsIgnoreCase(fTitle)) throw new DAOException("Designation :"+fTitle+"exist");
}
//int code=lastGeneratedCode+1;
lastGeneratedCode++;
raf.writeBytes(String.valueOf(lastGeneratedCode)+"\n"); 
raf.writeBytes(title+"\n"); 
designationDTO.setCode(lastGeneratedCode);
//lastGeneratedCode++;
recordCount++;
lastGeneratedCodeString=String.valueOf(lastGeneratedCode);
while(lastGeneratedCodeString.length()<10) lastGeneratedCodeString+=" ";
recordCountString=String.valueOf(recordCount);
while(recordCountString.length()<10) recordCountString+=" ";
raf.seek(0);
raf.writeBytes(lastGeneratedCodeString+"\n");
raf.writeBytes(recordCountString+"\n");
raf.close();
}
catch(IOException ioe)
{
throw new DAOException(ioe.getMessage());
}
}
public void update(DesignationDTOInterface designationDTO) throws DAOException
{
if(designationDTO==null) throw new DAOException("Designation is null");
int code=designationDTO.getCode();
if(code<=0) throw new DAOException("Invalid code"+code);
String title=designationDTO.getTitle();
if(title==null) throw new DAOException("Designation is null");
title=title.trim();
if(title.length()==0) throw new DAOException("Length of Designation is zero");
try
{
File f=new File(FILE_NAME);
if(f.exists()==false) throw new DAOException("Designation is null");
RandomAccessFile raf=new RandomAccessFile(f,"rw");
if(raf.length()==0) 
{
raf.close();
throw new DAOException("Designation is null");
}
boolean found=false;
String fTitle;
int fCode;
raf.readLine();
raf.readLine();
while(raf.getFilePointer()<raf.length())
{
fCode=Integer.parseInt(raf.readLine());
if(fCode==code)
{
found=true;
break;
}
raf.readLine();
}
if(found==false)
{
raf.close();
throw new DAOException("Incorrect code");
}
raf.seek(0);
raf.readLine();
raf.readLine();
while(raf.getFilePointer()<raf.length())
{
fCode=Integer.parseInt(raf.readLine());
fTitle=raf.readLine();
if(fCode!=code && fTitle.equalsIgnoreCase(title))
{
raf.close();
throw new DAOException("Invalid input combination");
}
}
File ff=new File("tmp.data");
if(ff.exists()) ff.delete();
RandomAccessFile tempraf=new RandomAccessFile(ff,"rw");
raf.seek(0);
tempraf.writeBytes(raf.readLine()+"\n");
tempraf.writeBytes(raf.readLine()+"\n");
while(raf.getFilePointer()<raf.length())
{
fCode=Integer.parseInt(raf.readLine());
fTitle=raf.readLine();
if(fCode==code)
{
tempraf.writeBytes(String.valueOf(fCode)+"\n");
tempraf.writeBytes(title+"\n");
}
else
{
tempraf.writeBytes(String.valueOf(fCode)+"\n");
tempraf.writeBytes(fTitle+"\n");
}
}
raf.seek(0);
tempraf.seek(0);
while(tempraf.getFilePointer()<tempraf.length())
{
raf.writeBytes(tempraf.readLine()+"\n");
}
raf.setLength(tempraf.length());
tempraf.setLength(0);
raf.close();
tempraf.close();
}catch(IOException ioe)
{
throw new DAOException(ioe.getMessage());
}
}
public void delete(int code) throws DAOException
{
if(code<=0) throw new DAOException("Invalid code"+code);
try
{
File f=new File(FILE_NAME);
if(f.exists()==false) throw new DAOException("Designation is null");
RandomAccessFile raf=new RandomAccessFile(f,"rw");
if(raf.length()==0) 
{
raf.close();
throw new DAOException("Designation is null");
}
boolean found=false;
String fTitle="";
int fCode;
raf.readLine();
raf.readLine();
while(raf.getFilePointer()<raf.length())
{
fCode=Integer.parseInt(raf.readLine());
fTitle=raf.readLine();
if(fCode==code)
{
found=true;
break;
}
}
if(found==false)
{
raf.close();
throw new DAOException("Incorrect code");
}
if(new EmployeeDAO().isDesignationAlloted(code)==true)
{
raf.close();
throw new DAOException("Designation code is alloted to "+fTitle);
}
raf.seek(0);
File ff=new File("tmp.data");
if(ff.exists()) ff.delete();
RandomAccessFile tempraf=new RandomAccessFile(ff,"rw");
tempraf.writeBytes(raf.readLine()+"\n");
tempraf.writeBytes(raf.readLine()+"\n");
while(raf.getFilePointer()<raf.length())
{
fCode=Integer.parseInt(raf.readLine());
fTitle=raf.readLine();
if(fCode!=code)
{
tempraf.writeBytes(String.valueOf(fCode)+"\n");
tempraf.writeBytes(fTitle+"\n");
}
}
raf.seek(0);
tempraf.seek(0);
raf.writeBytes(tempraf.readLine()+"\n");
int recordCount=Integer.parseInt(tempraf.readLine().trim());
String recordCountString=String.valueOf(recordCount-1);
while(recordCountString.length()<10) recordCountString+=" ";
raf.writeBytes(recordCountString+"\n");
while(tempraf.getFilePointer()<tempraf.length())
{
raf.writeBytes(tempraf.readLine()+"\n");
}
raf.setLength(tempraf.length());
tempraf.setLength(0);
raf.close();
tempraf.close();
}catch(IOException ioe)
{
throw new DAOException(ioe.getMessage());
}
}
public Set<DesignationDTOInterface> getAll() throws DAOException
{
Set<DesignationDTOInterface> designations;
designations=new TreeSet<>();
try
{
File f=new File(FILE_NAME);
if(f.exists()==false) return designations;
RandomAccessFile raf=new RandomAccessFile(f,"rw");
if(raf.length()==0) 
{
raf.close();
return designations;
}
raf.readLine();
raf.readLine();
DesignationDTOInterface designationDTO;
int fCode;
String fTitle;
while(raf.getFilePointer()<raf.length())
{
designationDTO=new DesignationDTO();
fCode=Integer.parseInt(raf.readLine());
designationDTO.setCode(fCode);
fTitle=raf.readLine();
designationDTO.setTitle(fTitle);
designations.add(designationDTO);
}
raf.close();
return designations;
}
catch(IOException ioe)
{
throw new DAOException(ioe.getMessage());
}
}
public DesignationDTOInterface getByCode(int code) throws DAOException
{
if (code<=0) throw new DAOException("Invalid code" +code);
try
{
File f=new File(FILE_NAME);
if (f.exists()==false) throw new DAOException("Invalid code" +code);
RandomAccessFile raf=new RandomAccessFile(f,"rw");
if(raf.length()==0) 
{
raf.close();
throw new DAOException("Invalid code" +code);
}
raf.readLine();
int recordCount=Integer.parseInt(raf.readLine().trim());
if(recordCount==0)
{
raf.close();
throw new DAOException("Invalid code" +code);
}
int fcode;
String fTitle;
while(raf.getFilePointer()<raf.length())
{
fcode=Integer.parseInt(raf.readLine().trim());
if(fcode==code)
{
fTitle=raf.readLine();
raf.close();
DesignationDTOInterface designationDTO=new DesignationDTO();
designationDTO.setCode(code);
designationDTO.setTitle(fTitle);
return designationDTO;
}
raf.readLine();
}
raf.close();
throw new DAOException("Invalid code" +code);
}catch(IOException ioe)
{
throw new DAOException(ioe.getMessage());
}
}
public DesignationDTOInterface getByTitle(String title) throws DAOException
{
if (title==null) throw new DAOException("Invalid title" +title);
try
{
File f=new File(FILE_NAME);
if (f.exists()==false) throw new DAOException("Invalid title" +title);
RandomAccessFile raf=new RandomAccessFile(f,"rw");
if(raf.length()==0) 
{
raf.close();
throw new DAOException("Invalid title" +title);
}
raf.readLine();
int recordCount=Integer.parseInt(raf.readLine().trim());
if(recordCount==0)
{
raf.close();
throw new DAOException("Invalid title" +title);
}
int fcode;
String fTitle;
while(raf.getFilePointer()<raf.length())
{
fcode=Integer.parseInt(raf.readLine().trim());
fTitle=raf.readLine();
if(fTitle.equalsIgnoreCase(title))
{
raf.close();
DesignationDTOInterface designationDTO=new DesignationDTO();
designationDTO.setCode(fcode);
designationDTO.setTitle(fTitle);
return designationDTO;
}
}
raf.close();
throw new DAOException("Invalid title" +title);
}catch(IOException ioe)
{
throw new DAOException(ioe.getMessage());
}

}
public boolean codeExists(int code) throws DAOException
{
if (code<=0) return false;
try
{
File f=new File(FILE_NAME);
if (f.exists()==false) return false;
RandomAccessFile raf=new RandomAccessFile(f,"rw");
if(raf.length()==0) 
{
raf.close();
return false;
}
raf.readLine();
int recordCount=Integer.parseInt(raf.readLine().trim());
if(recordCount==0)
{
raf.close();
return false;
}
int fcode;
String fTitle;
while(raf.getFilePointer()<raf.length())
{
fcode=Integer.parseInt(raf.readLine().trim());
if(fcode==code)
{
fTitle=raf.readLine();
raf.close();
DesignationDTOInterface designationDTO=new DesignationDTO();
designationDTO.setCode(code);
designationDTO.setTitle(fTitle);
return true;
}
raf.readLine();
}
raf.close();
return false;
}catch(IOException ioe)
{
throw new DAOException(ioe.getMessage());
}
}
public boolean titleExists(String title) throws DAOException
{
if (title==null) return false;
try
{
File f=new File(FILE_NAME);
if (f.exists()==false) return false;
RandomAccessFile raf=new RandomAccessFile(f,"rw");
if(raf.length()==0) 
{
raf.close();
return false;
}
raf.readLine();
int recordCount=Integer.parseInt(raf.readLine().trim());
if(recordCount==0)
{
raf.close();
return false;
}
int fcode;
String fTitle;
while(raf.getFilePointer()<raf.length())
{
fcode=Integer.parseInt(raf.readLine().trim());
fTitle=raf.readLine();
if(fTitle.equalsIgnoreCase(title))
{
raf.close();
DesignationDTOInterface designationDTO=new DesignationDTO();
designationDTO.setCode(fcode);
designationDTO.setTitle(fTitle);
return true;
}
}
raf.close();
return false;
}catch(IOException ioe)
{
throw new DAOException(ioe.getMessage());
}
}
public int getCount() throws DAOException
{
try
{
File f=new File(FILE_NAME);
if(f.exists()==false) return 0;

RandomAccessFile raf=new RandomAccessFile(f,"rw");
if(raf.length()==0) 
{
raf.close(); 
return 0;
}
raf.readLine();
int count=Integer.parseInt(raf.readLine().trim());
raf.close();
return count;
}catch(IOException ioe)
{
throw new DAOException(ioe.getMessage());
}
}
}
