package com.thinking.machines.hr.bl.managers;
import com.thinking.machines.hr.bl.interfaces.pojo.*;
import com.thinking.machines.hr.bl.interfaces.managers.*;
import com.thinking.machines.hr.bl.pojo.*;
import com.thinking.machines.hr.bl.exceptions.*;
import java.util.*;
import com.thinking.machines.network.common.*;
import com.thinking.machines.network.client.*;
import com.thinking.machines.network.common.exceptions. *;

public class DesignationManager implements DesignationManagerInterface,java.io.Serializable
{
private static DesignationManager designationManager=null;
private DesignationManager() throws BLException
{
}

public static DesignationManagerInterface getDesignationManager() throws BLException
{
if(designationManager==null) designationManager=new DesignationManager();
return designationManager;
}

public void addDesignation(DesignationInterface designation) throws BLException
{
BLException blException=new BLException();
if(designation==null)
{
blException.setGenericException("Designation Required");
throw blException;
}
String title=designation.getTitle();
int code=designation.getCode();
if(code!=0)
{
blException.addException("code","code should be zero");
}
if(title==null)
{
blException.addException("title","title Required");
title="";
}
else
{
title=title.trim();
if(title.length()==0)
{
blException.addException("title","Title Required");
}
}
if(blException.hasExceptions())
{
throw blException;
}
Request request=new Request();
request.setManager(Managers.getManagerType(Managers.DESIGNATION));
request.setAction(Managers.getAction(Managers.Designation.ADD_DESIGNATION));
request.setArguements(designation);
NetworkClient client=new NetworkClient();
try
{
Response response=client.send(request);
if(response.hasException())
{
blException=(BLException)response.getException();
throw blException;
}
DesignationInterface d=(DesignationInterface)response.getResult();
designation.setCode(d.getCode());
}catch(NetworkException ne)
{
blException.setGenericException(ne.getMessage());
throw blException;
}
}
public void updateDesignation(DesignationInterface designation) throws BLException
{
BLException blException=new BLException();
if(designation==null)
{
blException.setGenericException("Designation Required");
throw blException;
}
String title=designation.getTitle();
int code=designation.getCode();
if(code<=0)
{
blException.addException("code","code should be +ve");
}
if(title==null)
{
blException.addException("title","title Required");
title="";
}
else
{
title=title.trim();
if(title.length()==0)
{
blException.addException("title","Title Required");
}
}
if(blException.hasExceptions())
{
throw blException;
}
Request request=new Request();
request.setManager(Managers.getManagerType(Managers.DESIGNATION));
request.setAction(Managers.getAction(Managers.Designation.UPDATE_DESIGNATION));
request.setArguements(designation);
NetworkClient client=new NetworkClient();
try
{
Response response=client.send(request);
if(response.hasException())
{
blException=(BLException)response.getException();
throw blException;
}
}catch(NetworkException daoe)
{
blException.setGenericException(daoe.getMessage());
throw blException;
}
}

public void removeDesignation(int code) throws BLException
{
if(code<=0)
{
BLException blException=new BLException();
blException.addException("code","code should be +ve");
throw blException;
}
Request request=new Request();
request.setManager(Managers.getManagerType(Managers.DESIGNATION));
request.setAction(Managers.getAction(Managers.Designation.REMOVE_DESIGNATION));
request.setArguements(code);
NetworkClient client=new NetworkClient();
try
{
Response response=client.send(request);
if(response.hasException())
{
BLException blException=new BLException();
blException=(BLException)response.getException();
throw blException;
}
}catch(NetworkException daoe)
{
BLException blException=new BLException();
blException.setGenericException(daoe.getMessage());
throw blException;
}
}

public DesignationInterface getDesignationByCode(int code) throws BLException
{
BLException blException=new BLException();
Request request=new Request();
request.setManager(Managers.getManagerType(Managers.DESIGNATION));
request.setAction(Managers.getAction(Managers.Designation.GET_DESIGNATION_BY_CODE));
request.setArguements(code);
NetworkClient client=new NetworkClient();

try
{
Response response=client.send(request);
if(response.hasException())
{
blException=(BLException)response.getException();
throw blException;
}
DesignationInterface d=(DesignationInterface)response.getResult();
return d;
}catch(NetworkException daoe)
{
blException.setGenericException(daoe.getMessage());
throw blException;
}
}


public DesignationInterface getDesignationByTitle(String title) throws BLException
{
if(title==null)
{
BLException blException=new BLException();
blException.addException("title","Title required");
}
if(title.length()==0)
{
BLException blException=new BLException();
blException.addException("title","Title required");
throw blException;
}
Request request=new Request();
request.setManager(Managers.getManagerType(Managers.DESIGNATION));
request.setAction(Managers.getAction(Managers.Designation.GET_DESIGNATION_BY_TITLE));
request.setArguements(title);
NetworkClient client=new NetworkClient();
try
{
Response response=client.send(request);
if(response.hasException())
{
BLException blException=new BLException();
blException=(BLException)response.getException();
throw blException;
}
DesignationInterface d=(DesignationInterface)response.getResult();
return d;
}catch(NetworkException daoe)
{
BLException blException=new BLException();
blException.setGenericException(daoe.getMessage());
throw blException;
}
}

public Set<DesignationInterface> getDesignations() 
{
BLException blException=new BLException();

Request request=new Request();
request.setManager(Managers.getManagerType(Managers.DESIGNATION));
request.setAction(Managers.getAction(Managers.Designation.GET_DESIGNATIONS));
NetworkClient client=new NetworkClient();
DesignationInterface d=null;
try
{
Response response=client.send(request);
Set<DesignationInterface> designations;
designations=(Set<DesignationInterface>)response.getResult();
return designations;
}catch(NetworkException daoe)
{
throw new RuntimeException(daoe.getMessage());
}
}

public boolean codeExists(int code) 
{
if(code<=0)
{
return false;
}
BLException blException=new BLException();
Request request=new Request();
request.setManager(Managers.getManagerType(Managers.DESIGNATION));
request.setAction(Managers.getAction(Managers.Designation.CODE_EXISTS));
request.setArguements(code);
NetworkClient client=new NetworkClient();
try
{
Response response=client.send(request);
return (Boolean)response.getResult();
}catch(NetworkException daoe)
{
throw new RuntimeException(daoe.getMessage());
}
}

public boolean titleExists(String title) 
{
if(title==null)
{
return false;
}
if(title.length()==0)
{
return false;
}
Request request=new Request();
request.setManager(Managers.getManagerType(Managers.DESIGNATION));
request.setAction(Managers.getAction(Managers.Designation.TITLE_EXISTS));
request.setArguements(title);
NetworkClient client=new NetworkClient();
try
{
Response response=client.send(request);
Boolean exist=(Boolean)response.getResult();
return exist;
}catch(NetworkException daoe)
{
throw new RuntimeException(daoe.getMessage());
}
}
public int getDesignationCount()
{
Request request=new Request();
request.setManager(Managers.getManagerType(Managers.DESIGNATION));
request.setAction(Managers.getAction(Managers.Designation.GET_DESIGNATION_COUNT));
NetworkClient client=new NetworkClient();
try
{
Response response=client.send(request);
int x=0;
x=(Integer)response.getResult();
return x;
}catch(NetworkException daoe)
{
throw new RuntimeException(daoe.getMessage());
}
}
}