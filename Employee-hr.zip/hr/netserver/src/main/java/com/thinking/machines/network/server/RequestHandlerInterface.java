package com.thinking.machines.network.server;
import com.thinking.machines.network.common.*;
public interface RequestHandlerInterface
{
public Response process(Request request);
}