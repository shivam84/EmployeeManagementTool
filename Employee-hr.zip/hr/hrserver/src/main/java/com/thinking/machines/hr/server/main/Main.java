package com.thinking.machines.hr.server.main;
import com.thinking.machines.hr.server.*;
import com.thinking.machines.network.common.exceptions.*;
import com.thinking.machines.network.server.*;
public class Main
{
public static void main(String gg[])
{
try
{
RequestHandler rh=new RequestHandler();
NetworkServer ns;
ns=new NetworkServer(rh);
ns.start();
}catch(NetworkException ne)
{
System.out.println(ne);
}
}
}